/***************************************************************
 * Name:      ArrayFenetreDetachable.cpp
 * Purpose:   Code for Fu(X) 2.0
 * Author:    David Lecoconnier (etrange02@aol.com)
 * Created:   2012-01-24
 * Copyright: David Lecoconnier (http://www.fuxplay.com)
 * License:
 **************************************************************/
#include "ArrayFenetreDetachable.h"

/**
 * @class ArrayFenetreDetachable
 * @brief Array contenant des FenetreDetachable
 */

/**
 * Constructeur
 */
ArrayFenetreDetachable::ArrayFenetreDetachable()
{}

/**
 * Destructeur
 */
ArrayFenetreDetachable::~ArrayFenetreDetachable()
{
    Vider();
}

/**
 * Supprime tous les �l�ments pr�sents dans l'array
 */
void ArrayFenetreDetachable::Vider()
{
    for (size_t i = 0; i< GetCount(); i++)
        Item(i)->Destroy();
}

/**
 * Cr�e une fen�tre avec les �l�ments donn�s en param�tres puis ajoute celle-ci dans l'array
 * @param parent l'ancien parent du panel
 * @param page le panel devant changer de parent
 * @param sizer le sizer contenant le panel
 * @param type correspond au type du panel
 * @param idBouton l'identifiant du bouton �tant � l'origine de cette fen�tre
 * @param titre le titre de la fen�tre
 */
void ArrayFenetreDetachable::Add(wxWindow* parent, wxWindow* page, wxSizer* sizer, int type, int idBouton, wxString titre)
{
    FenetreDetachable *f = new FenetreDetachable(parent, page, sizer, type, idBouton, titre);
    f->Show();
    ArrayOfFenetreDetachable::Add(f);
}

/**
 * Indique si une fen�tre a �t� cr��e � partir de l'identifiant d'un bouton
 * @param idBouton l'identifiant du bouton
 * @return vrai si la fen�tre existe, faux sinon
 */
bool ArrayFenetreDetachable::IsInsideBouton(int idBouton)
{
    bool result = false;
    size_t i = 0;
    while (!result && i < GetCount())
    {
        if (Item(i)->GetIdBouton() == idBouton)
            result = true;
        i++;
    }
    return result;
}

/**
 * Indique si une fen�tre a �t� cr��e � partir du type de panel contenu
 * @param type le type de panel associ�
 * @return vrai si la fen�tre existe, faux sinon
 */
bool ArrayFenetreDetachable::IsInsideType(int type)
{
    bool result = false;
    size_t i = 0;
    while (!result && i < GetCount())
    {
        if (Item(i)->GetType() == type)
            result = true;
        i++;
    }
    return result;
}

/**
 * Retourne la FenetreDetachable correspondant � l'idBouton
 * @param idBouton l'identifiant du bouton � l'origine de la fen�tre
 * @return un pointeur sur la fen�tre
 */
FenetreDetachable* ArrayFenetreDetachable::GetFenetreByIdBouton(int idBouton)
{
    if (IsInsideBouton(idBouton))
    {
        size_t i = 0;
        while (i < GetCount())
        {
            if (Item(i)->GetIdBouton() == idBouton)
                return Item(i);
            i++;
        }
        return NULL;
    }
    else
        return NULL;
}

/**
 * Retourne la FenetreDetachable correspondant au type
 * @param type le type du panel contenu dans la fen�tre
 * @return un pointeur sur la fen�tre
 */
FenetreDetachable* ArrayFenetreDetachable::GetFenetreByType(int type)
{
    if (IsInsideType(type))
    {
        size_t i = 0;
        while (i < GetCount())
        {
            if (Item(i)->GetType() == type)
                return Item(i);
            i++;
        }
        return NULL;
    }
    else
        return NULL;
}

