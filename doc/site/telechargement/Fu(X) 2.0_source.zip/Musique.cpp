/***************************************************************
 * Name:      Musique.cpp
 * Purpose:   Code for Fu(X) 2.0
 * Author:    David Lecoconnier (etrange02@aol.com)
 * Created:   2009-08-04
 * Copyright: David Lecoconnier (http://www.fuxplay.com)
 * License:
 **************************************************************/
#include "Musique.h"

/**
 * @class Musique
 * @brief Classe centrale de Fu(X). Elle g�re la lecture ainsi que toutes les op�rations li�es.
 */

static Musique* instanceMusique = NULL;

const wxEventType wxEVT_MUSIQUE_CHANGE = wxNewEventType();
const wxEventType wxEVT_MUSIQUE_MAJ = wxNewEventType();
const wxEventType wxEVT_MUSIQUE_LECTURE = wxNewEventType();
const wxEventType wxEVT_MUSIQUE_GRAPH = wxNewEventType();


/**
 * Constructeur
 * @param parent la classe (= fen�tre) parente pour l'envoi d'�v�nement
 */
Musique::Musique(wxWindow *parent)
{
    instanceMusique = this;
    m_parent = parent;
    FMOD_System_Create(&m_system);
    //wxString cheminPluginAAC = wxStandardPaths::Get()->GetDataDir(); cheminPluginAAC << wxFileName::GetPathSeparator() << "codec_aac.dll";
    //FMOD_System_LoadPlugin(m_system, cheminPluginAAC.c_str(), &codec, /*FMOD_PLUGINTYPE_CODEC, */2600);
    //FMOD_System_SetOutputByPlugin(m_system, codec);

    FMOD_System_Init(m_system, 1, FMOD_INIT_NORMAL, NULL);//(void*)cheminPluginAAC.c_str());//

    m_liste = new wxFichierListe();
    m_liste->Init();
    m_stop = true;
    m_action = SUIVANT;
    m_musCharge = false;

    m_duree.msecondeTot = 1;
    m_tpsActuel.msecondeTot = 0;
    m_volume = 1;

    m_aleatoire = false;
    m_isPlaying = false;
    srand(time(NULL));
}

/**
 * Destructeur
 */
Musique::~Musique()
{
    FMOD_Sound_Release(m_sound);
    //FMOD_System_UnloadPlugin(m_system, codec);
    FMOD_System_Release(m_system);
    m_liste->Fermeture();
}

/**
 * R�cup�re l'instance de la classe
 * @return l'instance
 */
Musique* Musique::Get()
{    return instanceMusique;}

/**
 * G�re le chargement du titre � �couter. Informe le reste de l'application du changement gr�ce aux �v�nements
 * @param nomChanson le titre
 */
void Musique::Lecture(wxString nomChanson)
{
    FMOD_System_CreateStream(m_system, nomChanson.c_str(), /*FMOD_LOOP_OFF | FMOD_2D | */FMOD_SOFTWARE, 0, &m_sound);

    FMOD_System_PlaySound(m_system, FMOD_CHANNEL_FREE, m_sound, 0, &m_channel);
    FMOD_Channel_SetVolume(m_channel, m_volume);

    m_cheminComplet = nomChanson;
    DureeMS();
    m_musCharge = true;
    m_isPlaying = true;
    m_stop = false;

    m_nomChanson = m_cheminComplet.AfterLast(wxFileName::GetPathSeparator());
    wxString chaineT = m_cheminComplet.BeforeLast(wxFileName::GetPathSeparator());
    m_album = chaineT.AfterLast(wxFileName::GetPathSeparator());

    chaineT = chaineT.BeforeLast(wxFileName::GetPathSeparator());
    m_artiste = chaineT.AfterLast(wxFileName::GetPathSeparator());

    FichierLog::Get()->Ajouter("Musique::Lecture - " + m_nomChanson);

    if (m_parent)
    {
        wxCommandEvent evt(wxEVT_MUSIQUE_CHANGE, wxID_ANY);
        evt.SetInt(1);
        m_parent->GetEventHandler()->AddPendingEvent(evt);
        wxCommandEvent evt2(wxEVT_MUSIQUE_GRAPH, wxID_ANY);
        m_parent->GetEventHandler()->AddPendingEvent(evt2);
    }
}

/**
 * Suspend ou relance la lecture
 * @param etat si vrai, met la lecture sur pause sinon la relance
 */
void Musique::SetPause(bool etat)
{
    FMOD_Channel_SetPaused(m_channel, etat);
    FMOD_BOOL result;
    FMOD_Channel_GetPaused(m_channel, &result);
    m_isPlaying = !result;
    if (m_parent)
    {
        wxCommandEvent evt(wxEVT_MUSIQUE_LECTURE, wxID_ANY);
        evt.SetInt((result) ? 1 : 0);
        m_parent->GetEventHandler()->AddPendingEvent(evt);
    }
}

/**
 * Indique si l'�coute est en pause ou non. Pause ne veut pas dire stopp�
 * @return vrai si en pause
 */
bool Musique::GetPause()
{
    FMOD_BOOL result;
    FMOD_Channel_GetPaused(m_channel, &result);

    return result;
}

/**
 * Stop la lecture
 */
void Musique::SetStop()
{
    FMOD_Channel_Stop(m_channel);
    m_stop = true;
    m_isPlaying = false;
}

/**
 * D�finie la fa�on dont le prochain titre sera � lire. N'est utilis� que lorsque la chanson actuelle est finie.
 * @param action l'action � faire : SUIVANT, PRECEDENT, IDENTIQUE
 */
void Musique::SetAction(e_ChangeChanson action)
{    m_action = action;}

/**
 * Effectus le changement de chanson en fonction de la valeur contenu dans action
 * @param action
 * @return vrai si r�ussite
 * @see Musique::SetAction(e_ChangeChanson)
 */
bool Musique::ChangementChanson(e_ChangeChanson action)
{
    if (m_liste->GetNombreFichier() == 0)
    {
        /*m_nomChanson = wxEmptyString;
        m_cheminComplet = wxEmptyString;
        wxCommandEvent evt(wxEVT_MUSIQUE_CHANGE, GetId());
        evt.SetInt(0);
        GetParent()->GetEventHandler()->AddPendingEvent(evt);*/
        ModifListeVide();
        return false;
    }

    m_positionListe = m_liste->GetPositionListe(m_cheminComplet, m_positionListe);

    if (action == PRECEDENT)
    {
        if (!m_aleatoire)
        {
            m_positionListe--;
            if (m_positionListe <0)
                m_positionListe = m_liste->GetNombreFichier() -1;
        }
        else
            m_positionListe = rand() % m_liste->GetNombreFichier();
    }
    else if (action == SUIVANT)
    {
        if(!m_aleatoire)
        {
            if (m_positionListe == -1)
                m_positionListe = 0;
            else
                m_positionListe++;

            if (m_positionListe >= m_liste->GetNombreFichier())
                m_positionListe = 0;
        }
        else
            m_positionListe = rand() % m_liste->GetNombreFichier();
    }
    else if (action == IDENTIQUE)
    {}
    else
        return false;

    m_cheminComplet = m_liste->GetNomPosition(m_positionListe);

    if (!wxFileExists(m_cheminComplet))
        return false;

    SetStop();
    FMOD_Sound_Release(m_sound);

    FichierLog::Get()->Ajouter("Musique:ChangementChanson");
    Lecture(m_cheminComplet);

    return true;
}

/**
 * Changement de titre "automatique"
 * @return vrai si r�ussite
 * @see Musique::ChangementChanson(e_ChangeChanson)
 */
bool Musique::ChangementChanson()
{
    return Musique::ChangementChanson(m_action);
}

/**
 * Change le titre avec les arguments qui lui sont envoy�s. Cette m�thode est utilis�e par ListeLecture et GestionPeriphMoitiePage.
 *Si la position vaut -1, le titre lu sera la premi�re occurrence de chaine. Sinon, la recherche est faite � partir de la position peu importe le contenu de chaine.
 * @param position la position du titre dans la liste (ou dans le fichier musique.liste)
 * @param chaine l'adresse du titre
 * @return vrai si r�ussite
 */
bool Musique::ChangementChanson(long position, wxString chaine)
{

    if (m_liste->GetNombreFichier() == 0)
    {
        ModifListeVide();
        return false;
    }

    if (position != -1)
        chaine = m_liste->GetNomPosition(position);
    else
        position = m_liste->GetPositionListe(chaine, -1);
    if (chaine.IsEmpty())// || !wxFileExists(chaine))
        return false;

    m_cheminComplet = chaine;
    m_positionListe = position;
    return ChangementChanson(IDENTIQUE);
    /*SetStop();
    FMOD_Sound_Release(m_sound);
    Lecture(chaine);
    m_positionListe = position;

    return true;*/
}

/**
 * Provoque le remplissage de la liste de lecture. Elle est utilis�e lorsque le fichier est vide. Le contenu du fichier correspond donc au contenu du dossier contenant le titre envoy� en lecture
 */
void Musique::Listage()
{
    m_liste->SetDossierRecherche(m_cheminComplet);
    m_liste->ListageFichier();
    m_positionListe = m_liste->GetPositionListe(m_cheminComplet);
}

/**
 * Provoque l'ajout de chaine � la liste de lecture
 * chaine un tableau de wxString contenant des adresses
 * maj si vrai, informa l'application du changement (pas toujours n�cessaire)
 */
void Musique::Listage(wxArrayString *chaine, bool maj)
{
    m_liste->ListageFichier(chaine);
    Recharger(maj);
    FichierLog::Get()->Ajouter("Musique::Listage - tableau");
}

/**
 * Modifie la liste de lecture en d�pla�ant un ensemble de titres � la position pos dans la liste
 * @param chaine contient les positions des titres � d�placer
 * @param pos la ligne o� doivent se retrouver les titres
 * @param maj si une mise � jour des tableaux est n�cessaires
 * @param supprim doit valoir vrai
 */
void Musique::PlacerLigneInt(wxArrayString* chaine, long pos, bool maj, bool supprime)
{
    m_liste->PlacerLigneInt(chaine, pos, supprime);
    Recharger(maj, true);
}

/**
 * Modifie la liste de lecture en ajoutant un ensemble de titres � la position pos dans la liste
 * @param chaine contient les noms des titres
 * @param pos la ligne o� doivent �tre plac�e les titres
 * @param maj si une mise � jour des tableaux est n�cessaires
 */
void Musique::PlacerLigneString(wxArrayString* chaine, long pos, bool maj)
{
    m_liste->PlacerLigneString(chaine, pos);
    Recharger(maj, true);
}


/**
 * Provoque l'ajout de chaine � la liste de lecture
 * chaine l'adresse du titre � ajouter
 */
 void Musique::Listage(wxString chaine)
{
    if (Parametre::Get()->islisable(chaine.AfterLast('.').Lower()))
    {
        m_liste->ListageFichier(chaine);
        if (!m_musCharge)
            Lecture(chaine);//ChangementChanson(0, "");
    }
}

/**
 * Provoque l'ajout � la liste de lecture du contenu du fichier donn� en param�tre. Ce fichier doit �tre au format .m3u !
 * @param chemin l'adresse du fichier
 */
void Musique::CopieFichier(wxString chemin)
{
    if (m_liste->CopieFichierTOListe(chemin, m_parent))
        ChangementChanson(0, "");
}

/**
 * Modifie (en interne) le contenu de m_duree : traduit le temps en ms de la chanson en minutes et secondes
 */
void Musique::DureeMS()
{
    unsigned int temps;
    FMOD_Sound_GetLength(m_sound, &temps, FMOD_TIMEUNIT_MS);

    m_duree.msecondeTot = temps;
    temps/=1000;
    m_duree.seconde = temps%60;
    m_duree.minute = temps/60;
}

/**
 * Modifie (en interne) le contenu de m_tpsActuel : traduit le temps en ms de la chanson en minutes et secondes
 */
void Musique::TpsActuelMS()
{
    unsigned int position;
    FMOD_Channel_GetPosition(m_channel, &position, FMOD_TIMEUNIT_MS);

    m_tpsActuel.msecondeTot = position;
    position/=1000;
    m_tpsActuel.seconde = position%60;
    m_tpsActuel.minute = position/60;
}

/**
 * Indique si l'on arrive � la fin du titre
 * @param vrai si fin du titre
 */
bool Musique::VerifTemps()
{
    if (m_musCharge)
        TpsActuelMS();
    else
        return false;

    if (m_tpsActuel.msecondeTot >= m_duree.msecondeTot - 200)
        return true;
    else
        return false;
}

/**
 * Retourne la dur�e en ms de la chanson
 * @return la dur�e
 */
int Musique::GetDureeMS()
{    return m_duree.msecondeTot;}

/**
 * Retourne le temps �coul� en ms de la chanson
* @return le temps �coul�
 */
int Musique::GetTpsActuel()
{    return m_tpsActuel.msecondeTot;}

/**
 * Retourne la structure contenant les informations sur la dur�e du titre
 * @return la dur�e
 */
DUREE Musique::GetDUREEDuree()
{    return m_duree;}

/**
 * Retourne la structure contenant les informations sur le temps �coul� du titre
 * @return le temps �coul�
 */
DUREE Musique::GetDUREETpsActuel()
{    return m_tpsActuel;}

/**
 * D�place le curseur de lecture
 * @param temps la position en ms
 */
void Musique::SetPositionMS(int temps)
{    FMOD_Channel_SetPosition(m_channel, temps, FMOD_TIMEUNIT_MS);}

/**
 * Indique si des titres ont �t� plac�s dans la liste de lecture
 * @return vrai si la liste n'est pas vide
 */
bool Musique::IsContainingMus()
{    return m_musCharge;}

/**
 * Indique si le mode de lecture est "r�p�tition"
 * @return vrai si r�p�tition du titre
 */
bool Musique::GetRepete()
{
    return (m_action == IDENTIQUE);
}

/**
 * Modifie l'action � effectuer lors de la fin du titre en fonction de etat. Si �tat est vrai, le titre sera lu en boucle sinon, un autre titre sera lu
 * @param etat
 */
void Musique::SetRepete(bool etat)
{
    m_action = (etat) ? IDENTIQUE : SUIVANT;
}

/**
 * Indique si l'on est en mode "Al�atoire"
 * @return vrai si al�atoire
 */
bool Musique::GetAleatoire()
{   return m_aleatoire;}

/**
 * Indique si un titre est en lecture (ni pause ni stop)
 * @return vrai si lecture (�coute)
 */
bool Musique::GetLecture()
{   return m_isPlaying;}

/**
 * Active ou d�sactive la lecture al�atoire
 * @param aleatoire si vrai, active l'al�atoire
 */
void Musique::SetAleatoire(bool aleatoire)
{   m_aleatoire = aleatoire;}

/**
 * Retourne le nom de la chanson "physique". Ex : chanson.mp3
 * @return le nom
 */
wxString Musique::GetNomChanson()
{    return m_nomChanson;}

/**
 * Retourne le nom de l'album selon la structure de fichier artiste\album\titre.
 * @return le nom
 */
wxString Musique::GetAlbum()
{    return m_album;}

/**
 * Retourne le nom de l'album selon la structure de fichier artiste\album\titre.
 * @return le nom
 */
wxString Musique::GetArtiste()
{    return m_artiste;}

/**
 * Retourne le nom et la position du titre en cours de lecture
 * @return la position et le nom
 */
ChansonNomPos Musique::GetNomPos()
{
    m_positionListe = m_liste->GetPositionListe(m_cheminComplet, m_positionListe);//m_liste.GetPositionListe(m_cheminComplet, m_positionListe));
    ChansonNomPos titre = {m_nomChanson, m_positionListe};
    return titre;
}

/**
 * Efface de la liste le titre en cours de lecture
 * @return le nom et la position du titre effac�
 */
ChansonNomPos Musique::SupprimerNom()
{
    if(m_liste->GetNombreFichier() == 0)
        return {"", -1};
    ChansonNomPos Asuppr = {m_cheminComplet, m_positionListe};

    if(m_liste->GetNombreFichier() > 1)
        ChangementChanson(SUIVANT);
    else
        ModifListeVide();

    m_liste->EffacerNom(Asuppr);
    m_positionListe--;
    return Asuppr;
}

/**
 * Efface de la liste le titre se trouvant � la position position.
 * @param position la position du titre � effacer
 */
void Musique::SupprimerNom(int position)//wxString chaine)
{
    ChansonNomPos titre = {m_liste->GetNomPosition(position), position};

    if (m_cheminComplet.IsSameAs(titre.Nom) && titre.Nom.Length() != 0 && titre.Pos == m_positionListe)//titre actuellement en cours de lecture
    {
        if(m_liste->GetNombreFichier() > 1)
            ChangementChanson(SUIVANT);
        else
            ModifListeVide();
        m_liste->EffacerNom(titre);
        m_positionListe--;
        FichierLog::Get()->Ajouter("Musique::SupprimerNom - (titre actuel) " + wxString::Format("%d", titre.Pos) + " - " + titre.Nom);
    }
    else
    {
        m_liste->EffacerNom(titre);
        if (m_positionListe > titre.Pos)
            m_positionListe--;
        FichierLog::Get()->Ajouter("Musique::SupprimerNom - " + wxString::Format("%d", titre.Pos) + " - " + titre.Nom);
    }
}

/**
 * Efface de la liste les titre se trouvant dans tableau. Si le titre en �coute se trouve dans cette liste, un titre ne se trouvant pas dans celle-ci est lu
 * @param tableau les titres � effacer
 * @param maj vrai si une mise � jour des tableaux est � faire
 */
void Musique::SupprimerNom(wxArrayString *tableau, bool maj)
{
    unsigned int i = 0, taille = tableau->GetCount(), pos = 0;
    m_positionListe = m_liste->GetPositionListe(m_cheminComplet, m_positionListe);
    bool change = false;

    while (i<taille && change == false)
    {
        if (m_cheminComplet.IsSameAs(tableau->Item(i)))
        {
            change = true;
            pos = m_positionListe - i;
        }
        i++;
    }

    m_liste->EffacerNom(tableau);

    if (change)
    {
        if (m_liste->GetNombreFichier() > 1)
        {
            if (m_positionListe >= m_liste->GetNombreFichier())
                    m_positionListe = 0;
            else
                m_positionListe = pos;
            ChangementChanson(m_positionListe, m_liste->GetNomPosition(m_positionListe));
        }
        else
            ModifListeVide();
    }
        Recharger(maj, false);
}

/**
 * Retourne le volume
 * @return le volume
 */
float Musique::GetVolume()
{
    float volume;
    FMOD_Channel_GetVolume(m_channel, &volume);
    return volume;
}

/**
 * Modifie le volume
 * @param volume le niveau sonore � appliquer
 */
void Musique::SetVolume(int volume)
{
    float vol = volume *0.01;
    m_volume = vol;
    FMOD_Channel_SetVolume(m_channel, m_volume);
}

/**
 * Retourne une chaine contenant les informations dur la dur�e su titre au format mm:ss
 * @return la chaine
 */
wxString Musique::GetDureeFormatMinSec()
{
    wxString chaine;
    chaine << m_duree.minute << ":" << m_duree.seconde;
    return chaine;
}

/**
 * Retourne l'instance de la classe wxFichierListe. A utiliser le moins possible !
 * @return l'instance
 */
wxFichierListe* Musique::GetFichier()
{    return m_liste;}

/**
 * Remplit le tableau spectre avec les valeurs du spectre du titre
 * @param spectre un tableau de taille largeur
 * @param largeur la taille du tableau
 */
void Musique::RemplirSpectre(float spectre[], int largeur)
{   FMOD_System_GetSpectrum(m_system, spectre, largeur, 0, FMOD_DSP_FFT_WINDOW_RECT);}

/**
 * Modifie les attributs de la classe pour prendre en compte le fait que la liste de lecture soit vide. Elle n'effectue aucun test.
 */
void Musique::ModifListeVide()
{
    SetStop();
    FMOD_Sound_Release(m_sound);
    if (m_parent)
    {
        wxCommandEvent evt(wxEVT_MUSIQUE_CHANGE, wxID_ANY);
        evt.SetInt(0);
        m_parent->GetEventHandler()->AddPendingEvent(evt);
    }
    m_musCharge = false;
    m_nomChanson = wxEmptyString;
    m_cheminComplet = wxEmptyString;
}

/**
 * Agit de fa�on globale sur l'application en fonction des param�tres
 * @param maj si vrai, provoque la mise � jour des tableaux
 * @param lect si vrai, provoque la lecture d'un titre
 */
void Musique::Recharger(bool maj, bool lect)
{
    if (maj && m_parent)
    {
        wxCommandEvent evt(wxEVT_MUSIQUE_MAJ, wxID_ANY);
        m_parent->GetEventHandler()->AddPendingEvent(evt);
    }
    if (lect && !m_musCharge)
    {
        if (!m_aleatoire)
            ChangementChanson(0, "");
        else
            ChangementChanson();
    }
}


