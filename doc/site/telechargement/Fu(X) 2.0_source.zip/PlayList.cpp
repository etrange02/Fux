/***************************************************************
 * Name:      PlayList.cpp
 * Purpose:   Code for Fu(X) 2.0
 * Author:    David Lecoconnier (etrange02@aol.com)
 * Created:   2009-12-17
 * Copyright: David Lecoconnier (http://www.fuxplay.com)
 * License:
 **************************************************************/

#include "PlayList.h"

/**
 * @class PlayList
 * @brief Page contenant la liste de lecture et une description d�taill�e des titres
 */

using namespace TagLib;

BEGIN_EVENT_TABLE(PlayList, wxPanel)
    EVT_BUTTON(ID_PAGE_PLAYLIST_BOUTON_ENREGISTRE_M3U, PlayList::EnregistrerM3U)
    EVT_COLLAPSIBLEPANE_CHANGED(ID_PAGE_PLAYLIST_PANNEAUREPLIABLE, PlayList::OnPanneau)
    EVT_LIST_ITEM_FOCUSED(ID_PAGE_PLAYLIST_LISTE, PlayList::OnAfficheDetails)
    EVT_BUTTON(ID_PAGE_PLAYLIST_BOUTON_APPLIQUER, PlayList::OnAppliquerTAG)
    EVT_BUTTON(ID_PAGE_PLAYLIST_BOUTON_ANNULER, PlayList::OnAnnulerTAG)
    EVT_VIDER_PANNEAU(ID_PAGE_PLAYLIST_LISTE, PlayList::EvtViderPanneauTAG)
    EVT_IMAGE_SELECTION(ID_PAGE_PLAYLIST_POCHETTE, PlayList::EvtImage)
    EVT_LISTE_DETAILS(ID_PAGE_PLAYLIST_LISTE, PlayList::FenetreDetails)
    EVT_MOUSE_EVENTS(PlayList::MouseEvents)
END_EVENT_TABLE()

/**
 * Constructeur
 * @see Creer
 */
PlayList::PlayList()
{}

/**
 * Constructeur
 * @param Parent le fen�tre parente
 */
PlayList::PlayList(wxWindow *Parent)
{   Creer(Parent);}

/**
 * Destructeur
 */
PlayList::~PlayList()
{}

/**
 * Retourne l'instance de la liste que g�re la page
 * @return le liste g�r�e par la page
 */
ListeLecture* PlayList::GetListeLecture()
{    return m_liste;}

/**
 * Cr�e les composants graphiques de la page
 * @param Parent un pointeur sur la fen�tre parente
 * @param MAJListe si vrai, la liste est mis � jour
 */
void PlayList::Creer(wxWindow *Parent, bool MAJListe)
{
    Create(Parent);
    m_musique = Musique::Get();
    sizer = new wxBoxSizer(wxVERTICAL);
    SetSizer(sizer);

    m_BoutonEnregistrerM3U = new wxButton(this, ID_PAGE_PLAYLIST_BOUTON_ENREGISTRE_M3U, _("Enregistrer la liste de lecture"));
    m_BoutonEnregistrerM3U->SetToolTip(_("Enregistre la liste de lecture au format m3u"));

    m_liste = new ListeLecture(this);

    m_panneauRepliable = new wxCollapsiblePane(this, ID_PAGE_PLAYLIST_PANNEAUREPLIABLE, _("D�tails"), wxDefaultPosition, wxDefaultSize, wxCP_NO_TLW_RESIZE | wxALWAYS_SHOW_SB);
    m_sizerRep = new wxBoxSizer(wxHORIZONTAL);
    m_sizerPann = new wxFlexGridSizer(3, 4, 1, 1);
    m_sizerBouton = new wxBoxSizer(wxVERTICAL);

    wxWindow *win = m_panneauRepliable->GetPane();
    m_pochette = new ImageMusique(win, ID_PAGE_PLAYLIST_POCHETTE, wxBitmap(POCHETTE_COTE, POCHETTE_COTE));
    m_pochette->SetSize(wxSize(POCHETTE_COTE, POCHETTE_COTE));
    m_pochette->AfficheImage(true);
    m_sizerRep->Add(m_pochette, 0, wxALL, 5);

    m_sizerRep->Add(m_sizerPann, 1, wxALL|wxEXPAND, 0);
    m_sizerRep->Add(m_sizerBouton, 0, wxALL|wxEXPAND, 0);//

    m_sizerPann->AddGrowableCol(1, 1);
    m_sizerPann->AddGrowableCol(3, 1);

    m_sizerPann->Add(new wxStaticText(win, wxID_ANY, _("Nom")), 1, wxGROW | wxALL, 5);
    m_BoiteNom = new wxTextCtrl(win, wxID_ANY, "");
    //m_BoiteNom->SetMinSize(wxSize(200, 21));
    m_sizerPann->Add(m_BoiteNom, 1, wxGROW | wxALL | wxEXPAND, 5);

    m_sizerPann->Add(new wxStaticText(win, wxID_ANY, _("Titre")), 1, wxGROW | wxALL, 5);
    m_BoiteTitre = new wxTextCtrl(win, wxID_ANY, "");
    //m_BoiteTitre->SetMinSize(wxSize(200, 21));
    m_sizerPann->Add(m_BoiteTitre, 1, wxGROW | wxALL | wxEXPAND, 5);

    m_sizerPann->Add(new wxStaticText(win, wxID_ANY, _("Artiste")), 1, wxGROW | wxALL, 5);
    m_BoiteArtiste = new wxTextCtrl(win, wxID_ANY, "");
    m_sizerPann->Add(m_BoiteArtiste, 1, wxGROW | wxALL | wxEXPAND, 5);

    m_sizerPann->Add(new wxStaticText(win, wxID_ANY, _("Genre")), 1, wxGROW | wxALL, 5);
    m_BoiteGenre = new wxTextCtrl(win, wxID_ANY, "");
    m_sizerPann->Add(m_BoiteGenre, 1, wxGROW | wxALL | wxEXPAND, 5);

    m_sizerPann->Add(new wxStaticText(win, wxID_ANY, _("Album")), 1, wxGROW | wxALL, 5);
    m_BoiteAlbum = new wxTextCtrl(win, wxID_ANY, "");
    m_sizerPann->Add(m_BoiteAlbum, 1, wxGROW | wxALL | wxEXPAND, 5);

    m_sizerPann->Add(new wxStaticText(win, wxID_ANY, _("Ann�e")), 1, wxGROW | wxALL, 5);
    m_BoiteAnnee = new wxSpinCtrl(win, wxID_ANY, "");
    m_BoiteAnnee->SetRange(0, 3000);
    m_sizerPann->Add(m_BoiteAnnee, 1, wxGROW | wxALL | wxEXPAND, 5);

    m_BoutonSauver = new wxButton(win, ID_PAGE_PLAYLIST_BOUTON_APPLIQUER, _("Enregistrer"));
    m_BoutonAnnuler = new wxButton(win, ID_PAGE_PLAYLIST_BOUTON_ANNULER, _("Annuler"));
    m_sizerBouton->Add(m_BoutonSauver, 1, wxALL, 5);
    m_sizerBouton->Add(m_BoutonAnnuler, 1, wxBOTTOM | wxLEFT | wxRIGHT, 5);

    win->SetSizer(m_sizerRep);

    sizer->Add(m_BoutonEnregistrerM3U, 0, wxUP | wxRIGHT | wxALIGN_RIGHT, 5);
    sizer->Add(m_liste, 1, wxALL | wxEXPAND, 5);
    sizer->Add(m_panneauRepliable, 0, wxGROW | wxDOWN | wxLEFT | wxRIGHT, 5);
    sizer->Layout();

    if (MAJListe)
        m_liste->MAJ();
}

/**
 * �v�nement - Affiche une bo�te de dialogue pour enregistrer la liste de lecture dans un fichier .m3u
 */
void PlayList::EnregistrerM3U(wxCommandEvent &WXUNUSED(event))
{
    DialogEnregistreM3U fen(this, wxID_ANY, wxEmptyString);
    fen.Creer();
    bool modif = true;

    if (fen.ShowModal() == wxID_OK)
    {
        wxTextFile fichierLec(Parametre::Get()->getRepertoireParametre("musique.liste"));
        if (!fichierLec.Open())
            return;
        wxTextFile fichierEcr(fen.GetChemin());

        if (fichierEcr.Exists())
        {
            wxMessageDialog boite2(NULL, _("Fichier d�j� existant. Souhaitez-vous le remplacer ?"), _("Fichier d�j� existant"), wxYES_NO|wxICON_QUESTION|wxCENTRE|wxYES_DEFAULT);
            if (boite2.ShowModal() != wxID_YES)
                modif = false;
            else
            {
                fichierEcr.Open();
                fichierEcr.Clear();
            }
        }
        else
        {
            if (!fichierEcr.Create())
            {
                wxLogError(_("Erreur dans le nom.\nV�rifiez que vous utilisez des caract�res autoris�s."), _("Erreur"));
                return;
            }
        }
        if (modif)
        {
            fichierEcr.AddLine("#EXTM3U");
            for (unsigned int i=0; i<fichierLec.GetLineCount(); i++)
                fichierEcr.AddLine(fichierLec.GetLine(i));
            fichierEcr.Write();

            if (fen.GetCheminRaccourci() != wxEmptyString && !wxFileExists(fen.GetCheminRaccourci()))
                if (!CreationRaccourci(fen.GetCheminRaccourci(), fen.GetChemin()))
                    wxLogMessage("Echec de la cr�ation du raccourci.");
        }
        fichierLec.Close();
        fichierEcr.Close();
    }
}

/**
 * �v�nement - Lors de l'ouverture/fermeture du panneau, redimensionne le sizer de la page
 */
void PlayList::OnPanneau(wxCollapsiblePaneEvent &WXUNUSED(event))
{    sizer->Layout();}

/**
 * �v�nement - Appel� lors de la s�lection d'une ligne dans la liste
 */
void PlayList::OnAfficheDetails(wxListEvent &event)
{
    ligneSel = event.GetIndex();
    fichierTAG = m_musique->GetFichier()->GetNomPosition(ligneSel);

    m_ObjetTAG = TagLib::FileRef(TagLib::FileName(fichierTAG.ToAscii()));
    if (!m_ObjetTAG.isNull() && m_ObjetTAG.file()->isValid())
    {
        TagLib::MPEG::File f(TagLib::FileName(fichierTAG.ToAscii()));

        if(f.ID3v2Tag())
        {
            TagLib::ID3v2::FrameList l = f.ID3v2Tag()->frameList("APIC");
            if (!l.isEmpty())
            {
                TagLib::ID3v2::AttachedPictureFrame *p = static_cast<TagLib::ID3v2::AttachedPictureFrame *>(l.front());
                int imgTaille = p->picture().size();

                if (p>0)
                {
                    wxMemoryOutputStream imgStreamOut;
                    imgStreamOut.Write(p->picture().data(), imgTaille);
                    wxMemoryInputStream stream(imgStreamOut);
                    wxString typeImage(p->mimeType().toCString(true), wxConvUTF8);

                    if (typeImage.IsSameAs("image/jpeg") || typeImage.IsSameAs("image/jpg"))
                        m_pochette->SetImage(wxImage(stream, "image/jpeg"));
                    m_pochette->AfficheImage(true);
                }
            }
            else
                m_pochette->AfficheImage(false);
        }
        RemplirPanneauTAG(fichierTAG);
        m_sizerRep->Layout();
    }
    else
        ViderPanneauTAG();
    m_ObjetTAG = TagLib::FileRef("");
}

/**
 * �v�nement - Applique les les modifications des TAGs au fichier s�lectionn�
 */
void PlayList::OnAppliquerTAG(wxCommandEvent &WXUNUSED(event))
{
    m_ObjetTAG = TagLib::FileRef(TagLib::FileName(fichierTAG.ToAscii()));
    if (!m_ObjetTAG.isNull() && ligneSel != m_liste->GetPositionChansonLecture())
    {
        wxString tempo = fichierTAG;
        wxString art = m_BoiteArtiste->GetValue();
        for (unsigned int j = 0; j < art.length(); j++)
        {
            if (art[j] == '/')
                art[j] = ';';
        }
        m_ObjetTAG.tag()->setArtist(TagLib::String(art.ToAscii()));//Artiste
        m_ObjetTAG.tag()->setAlbum(TagLib::String(m_BoiteAlbum->GetValue().ToAscii()));//Album
        m_ObjetTAG.tag()->setTitle(TagLib::String(m_BoiteTitre->GetValue().ToAscii()));//Titre
        m_ObjetTAG.tag()->setYear(m_BoiteAnnee->GetValue());//Ann�e
        if (m_BoiteGenre->GetValue().IsSameAs("Other") || m_BoiteGenre->GetValue().IsSameAs("Inconnu"))
            m_ObjetTAG.tag()->setGenre("");//Genre
        else
            m_ObjetTAG.tag()->setGenre(TagLib::String(m_BoiteGenre->GetValue().ToAscii()));//Genre
        m_ObjetTAG.save();
        m_ObjetTAG = TagLib::FileRef("");

        int i = tempo.Find(wxFileName::GetPathSeparator(), true);
        tempo = tempo.Left(i);
        tempo << wxFileName::GetPathSeparator() << m_BoiteNom->GetValue();//Nom du fichier
        if (fichierTAG != tempo)
        {
            if (wxRenameFile(fichierTAG, tempo, true))
                m_musique->GetFichier()->EchangeNom(fichierTAG, tempo);
            else
                wxMessageBox(_("Erreur dans le nom.\nV�rifiez que vous utilisez des caract�res autoris�s."), _("Erreur"));
        }
        m_liste->MAJ();
        m_liste->SetItemState(ligneSel, wxLIST_STATE_SELECTED | wxLIST_STATE_FOCUSED, wxLIST_STATE_SELECTED | wxLIST_STATE_FOCUSED);/////////////////////
    }
    else if (ligneSel == m_liste->GetPositionChansonLecture())
        wxMessageBox(_("Vous ne pouvez pas modifier un fichier lorsque celui-ci est en cours de lecture."), _("Erreur !"));
    else
        wxMessageBox(_("S�lectionnez un fichier"), _("Erreur !"));
}

/**
 * �v�nement - Remet les TAGs � leur valeur d'origine ie ceux dans le fichier
 */
void PlayList::OnAnnulerTAG(wxCommandEvent &WXUNUSED(event))
{
    m_ObjetTAG = TagLib::FileRef(TagLib::FileName(fichierTAG.ToAscii()));
    if (!m_ObjetTAG.isNull())
        RemplirPanneauTAG(fichierTAG);
    else
        wxMessageBox(_("S�lectionnez un fichier"), _("Erreur !"));
    m_ObjetTAG = TagLib::FileRef("");
}

/**
 * Efface tous les champs
 */
void PlayList::ViderPanneauTAG()
{
    m_BoiteNom->ChangeValue(wxEmptyString);//Nom du fichier
    m_BoiteArtiste->ChangeValue(wxEmptyString);//Artiste
    m_BoiteAlbum->ChangeValue(wxEmptyString);//Album
    m_BoiteTitre->ChangeValue(wxEmptyString);//Titre
    m_BoiteAnnee->SetValue(0);//Ann�e
    m_BoiteGenre->ChangeValue(wxEmptyString);//Genre
}

/**
 * Rempli les champs � partir d'un fichier
 * @param chaine le nom complet du fichier
 */
void PlayList::RemplirPanneauTAG(wxString chaine)
{
    m_ObjetTAG = TagLib::FileRef(TagLib::FileName(chaine.ToAscii()));
    int i = chaine.Find(wxFileName::GetPathSeparator(), true);

    m_BoiteNom->ChangeValue(chaine.Right(chaine.Length()-i-1));//Nom du fichier
    m_BoiteArtiste->ChangeValue(m_ObjetTAG.tag()->artist().toCString());//Artiste
    m_BoiteAlbum->ChangeValue(m_ObjetTAG.tag()->album().toCString());//Album
    m_BoiteTitre->ChangeValue(m_ObjetTAG.tag()->title().toCString());//Titre
    m_BoiteAnnee->SetValue(m_ObjetTAG.tag()->year());
    m_BoiteGenre->ChangeValue(m_ObjetTAG.tag()->genre().toCString());//Genre
    m_ObjetTAG = TagLib::FileRef("");
}

/**
 * �v�nement - Efface tous les champs
 */
void PlayList::EvtViderPanneauTAG(wxCommandEvent &WXUNUSED(event))
{    ViderPanneauTAG();}

/**
 * �v�nement - Appel� lors du changement de la pochette du titre. L'enregistrement dans le fichier se fait automatiquement
 */
void PlayList::EvtImage(wxCommandEvent &event)
{
    if (fichierTAG.IsEmpty())
        return;

    if (ligneSel != GetListeLecture()->GetPositionChansonLecture())
    {
        m_ObjetTAG = TagLib::FileRef(TagLib::FileName(fichierTAG.ToAscii()));
        if (!m_ObjetTAG.isNull())
        {
            if (m_ObjetTAG.file()->isValid())
            {
                TagLib::MPEG::File f(TagLib::FileName(fichierTAG.ToAscii()));
                if (f.ID3v2Tag())
                {
                    ID3v2::Tag *tagv2 = f.ID3v2Tag(true);
                    if(tagv2)
                    {
                        TagLib::ID3v2::AttachedPictureFrame *pict;
                        TagLib::ID3v2::FrameList FrameList = tagv2->frameListMap()["APIC"];
                        for( std::list<TagLib::ID3v2::Frame*>::iterator iter = FrameList.begin(); iter != FrameList.end(); iter++ )
                        {
                            pict = static_cast<TagLib::ID3v2::AttachedPictureFrame *>( *iter );
                            tagv2->removeFrame(pict, true);
                        }

                        TagLib::ID3v2::AttachedPictureFrame *p = new TagLib::ID3v2::AttachedPictureFrame;
                        p->setMimeType("image/jpeg");
                        p->setType(TagLib::ID3v2::AttachedPictureFrame::FrontCover);
                        wxMemoryOutputStream imgStreamOut;
                        wxImage pochette(event.GetString());
                        if(pochette.SaveFile(imgStreamOut, wxBITMAP_TYPE_JPEG))
                        {
                            ByteVector ImgData((TagLib::uint)imgStreamOut.GetSize());
                            imgStreamOut.CopyTo(ImgData.data(), imgStreamOut.GetSize());
                            p->setPicture(ImgData);
                            tagv2->addFrame(p);
                            if (f.save())
                                m_pochette->AfficheImage(true);
                        }
                    }
                }
            }
        }
        m_ObjetTAG = TagLib::FileRef("");
    }
    else
        wxLogMessage(_("Il est impossible de modifer les pochettes d'album lorsque\nle fichier est en cours de lecture."));
}

/**
 * �v�nement - Affiche une fen�tre d�taillant les propri�t�s du titre
 */
void PlayList::FenetreDetails(wxCommandEvent &WXUNUSED(event))
{
    DialogTagMP3 *fen = new DialogTagMP3(this, -1, "");

    m_ObjetTAG = TagLib::FileRef(TagLib::FileName(fichierTAG.ToAscii()));
    if (!m_ObjetTAG.isNull())
    {
        fen->SetChanson(fichierTAG);
        fen->SetArtiste(m_ObjetTAG.tag()->artist().toCString());//Artiste
        fen->SetAlbum(m_ObjetTAG.tag()->album().toCString());//Album
        fen->SetTitre(m_ObjetTAG.tag()->title().toCString());//Titre
        fen->SetAnnee(m_ObjetTAG.tag()->year());
        fen->SetGenre(m_ObjetTAG.tag()->genre().toCString());//Genre
        fen->SetDuree(m_liste->GetDuree(m_ObjetTAG.audioProperties()->length()));
        fen->SetDebit(m_ObjetTAG.audioProperties()->bitrate());
        fen->SetCommentaire(m_ObjetTAG.tag()->comment().toCString());
        fen->SetTaille(m_ObjetTAG.file()->length());

        {
            TagLib::MPEG::File f(TagLib::FileName(fichierTAG.ToAscii()));
            if(f.ID3v2Tag())
            {
                TagLib::ID3v2::FrameList l = f.ID3v2Tag()->frameList("APIC");
                if (!l.isEmpty())
                {
                    TagLib::ID3v2::AttachedPictureFrame *p = static_cast<TagLib::ID3v2::AttachedPictureFrame *>(l.front());
                    int imgTaille = p->picture().size();

                    if (p>0)
                    {
                        wxMemoryOutputStream imgStreamOut;
                        imgStreamOut.Write(p->picture().data(), imgTaille);
                        wxMemoryInputStream stream(imgStreamOut);
                        wxString typeImage(p->mimeType().toCString(true), wxConvUTF8);

                        if (typeImage.IsSameAs("image/jpeg") || typeImage.IsSameAs("image/jpg"))
                            fen->GetImage()->SetImage(wxImage(stream, "image/jpeg"));
                        fen->GetImage()->AfficheImage(true);
                    }
                }
                else
                    fen->GetImage()->AfficheImage(false);
            }
        }

        m_ObjetTAG = TagLib::FileRef("");

        fen->Layout();
        if (fen->ShowModal() == wxID_OK)
        {
            if (fen->IsModified())
            {
                m_ObjetTAG = TagLib::FileRef(TagLib::FileName(fichierTAG.ToAscii()));
                if (!m_ObjetTAG.isNull() && ligneSel != m_liste->GetPositionChansonLecture())
                {
                    wxString tempo = fichierTAG;
                    wxString art = fen->GetArtiste();
                    for (unsigned int j = 0; j < art.length(); j++)
                    {
                        if (art[j] == '/')
                            art[j] = ';';
                    }
                    m_ObjetTAG.tag()->setArtist(TagLib::String(art.ToAscii()));//Artiste
                    m_ObjetTAG.tag()->setAlbum(TagLib::String(fen->GetAlbum().ToAscii()));//Album
                    m_ObjetTAG.tag()->setTitle(TagLib::String(fen->GetTitre().ToAscii()));//Titre
                    m_ObjetTAG.tag()->setYear(fen->GetAnnee());//Ann�e
                    if (fen->GetGenre().IsSameAs("Other") || fen->GetGenre().IsSameAs("Inconnu"))
                        m_ObjetTAG.tag()->setGenre("");//Genre
                    else
                        m_ObjetTAG.tag()->setGenre(TagLib::String(fen->GetGenre().ToAscii()));//Genre
                    m_ObjetTAG.tag()->setComment(TagLib::String(fen->GetCommentaire().ToAscii()));
                    m_ObjetTAG.save();
                    m_ObjetTAG = TagLib::FileRef("");

                    int i = tempo.Find(wxFileName::GetPathSeparator(), true);
                    tempo = tempo.Left(i);
                    tempo << wxFileName::GetPathSeparator() << fen->GetNom();//Nom du fichier
                    if (fichierTAG != tempo)
                    {
                        if (wxRenameFile(fichierTAG, tempo, true))
                            m_musique->GetFichier()->EchangeNom(fichierTAG, tempo);
                        else
                            wxMessageBox(_("Erreur dans le nom.\nV�rifiez que vous utilisez des caract�res autoris�s."), _("Erreur"));
                    }

                    TagLib::MPEG::File f(TagLib::FileName(fichierTAG.ToAscii()));
                    ID3v2::Tag *tagv2 = f.ID3v2Tag(true);
                    if(tagv2 && fen->GetImage()->IsVoid())
                    {
                        TagLib::ID3v2::AttachedPictureFrame *pict;
                        TagLib::ID3v2::FrameList FrameList = tagv2->frameListMap()["APIC"];
                        for( std::list<TagLib::ID3v2::Frame*>::iterator iter = FrameList.begin(); iter != FrameList.end(); iter++ )
                        {
                            pict = static_cast<TagLib::ID3v2::AttachedPictureFrame *>( *iter );
                            tagv2->removeFrame(pict, true);
                        }

                        TagLib::ID3v2::AttachedPictureFrame *p = new TagLib::ID3v2::AttachedPictureFrame;
                        p->setMimeType("image/jpeg");
                        p->setType(TagLib::ID3v2::AttachedPictureFrame::FrontCover);
                        wxMemoryOutputStream imgStreamOut;
                        if(fen->GetImage()->GetImage().SaveFile(imgStreamOut, wxBITMAP_TYPE_JPEG))
                        {
                            ByteVector ImgData((TagLib::uint)imgStreamOut.GetSize());
                            imgStreamOut.CopyTo(ImgData.data(), imgStreamOut.GetSize());
                            p->setPicture(ImgData);
                            tagv2->addFrame(p);
                            f.save();
                        }
                    }
                    else if (fen->GetImage()->IsVoid())
                    {
                        TagLib::ID3v2::AttachedPictureFrame *pict;
                        TagLib::ID3v2::FrameList FrameList = tagv2->frameListMap()["APIC"];
                        for( std::list<TagLib::ID3v2::Frame*>::iterator iter = FrameList.begin(); iter != FrameList.end(); iter++ )
                        {
                            pict = static_cast<TagLib::ID3v2::AttachedPictureFrame *>( *iter );
                            tagv2->removeFrame(pict, true);
                        }
                        f.save();
                    }
                    m_liste->MAJ();
                    m_liste->SetItemState(ligneSel, wxLIST_STATE_SELECTED | wxLIST_STATE_FOCUSED, wxLIST_STATE_SELECTED | wxLIST_STATE_FOCUSED);/////////////////////
                }
                else if (ligneSel == m_liste->GetPositionChansonLecture())
                    wxMessageBox(_("Vous ne pouvez pas modifier un fichier lorsque celui-ci est en cours de lecture."), _("Erreur !"));
                else
                    wxMessageBox(_("S�lectionnez un fichier"), _("Erreur !"));
            }
        }
    }
    else
    {
        m_ObjetTAG = TagLib::FileRef("");
        wxMessageBox(_("S�lectionnez un fichier"), _("Erreur !"));
    }

    delete fen;
}

/**
 * �v�nement Souris -
 */
void PlayList::MouseEvents(wxMouseEvent &event)
{
    if (event.ControlDown() && event.GetWheelRotation() != 0)
    {
        if (event.GetWheelRotation() < 0)
            Musique::Get()->ChangementChanson(SUIVANT);
        else
            Musique::Get()->ChangementChanson(PRECEDENT);
    }
    else if (event.AltDown() && event.GetWheelRotation() != 0)
    {
        if (event.GetWheelRotation() < 0)
            SliderSon::Get()->SonUp();
        else
            SliderSon::Get()->SonDown();
    }
    else
        event.Skip();
}

