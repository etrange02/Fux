/***************************************************************
 * Name:      ImageFichierMusique.cpp
 * Purpose:   Code for Fu(X) 2.0
 * Author:    David Lecoconnier (etrange02@aol.com)
 * Created:   2010-09-01
 * Copyright: David Lecoconnier (http://www.fuxplay.com)
 * License:
 **************************************************************/

#include "ImageFichierMusique.h"

/**
 * @class ImageMusique
 * @brief Composant affichant une image, acceptant le Drag & Drop, et ouvre le navigateur de fichier pour changer l'image ; lors de tout changement, la fen�tre parente en est inform�e.
 */

BEGIN_EVENT_TABLE(ImageMusique, wxStaticBitmap)
    EVT_LEFT_DCLICK(ImageMusique::EvtSouris)
END_EVENT_TABLE()

const wxEventType wxEVT_IMAGE_SELECTION = wxNewEventType();

/**
 * Constructeur
 * @param Parent la fen�tre parente
 * @param id l'identifiant de l'instance
 * @param label un wxBitmap � modifier
 */
ImageMusique::ImageMusique(wxWindow *Parent, wxWindowID id, wxBitmap label) : wxStaticBitmap(Parent, id, label)
{
    m_pochetteBool = false;
    SetDropTarget(new DropFichierImage(this));
    m_redimension = true;
}

/**
 * Constructeur
 * @param Parent la fen�tre parente
 * @param id l'identifiant de l'instance
 */
ImageMusique::ImageMusique(wxWindow *Parent, wxWindowID id) : wxStaticBitmap(Parent, id, wxBitmap(20, 20))
{
    m_pochetteBool = false;
    SetDropTarget(new DropFichierImage(this));
    m_redimension = false;
}

/**
 * Desctructeur
 */
ImageMusique::~ImageMusique()
{}

/**
 * Si affiche vaut vrai, l'image est affich� sinon, elle est effac�e
 * @param affiche
 */
void ImageMusique::AfficheImage(bool affiche)
{
    int largeur = 0, hauteur = 0;
    GetSize(&largeur, &hauteur);
    if (affiche && m_image.IsOk())
    {
        m_pochetteBool = true;
        if (m_redimension)
            SetBitmap(wxBitmap(m_image.Scale(largeur, hauteur)));
        else
            SetBitmap(wxBitmap(m_image));
    }
    else
    {
        m_pochetteBool = false;
        m_image.Destroy();
        SetBitmap(wxBitmap(wxImage(largeur, hauteur)));
    }
}

/**
 * Retourne l'image
 * @return l'image
 */
wxImage ImageMusique::GetImage()
{    return m_image;}

/**
 * Modifie l'image courante sans modifier l'affichage
 * @param image la nouvelle image
 */
void ImageMusique::SetImage(wxImage image)
{    m_image = image;}

/**
 * �v�nement - Affiche une bo�te de dialogue pour s�lectionner une nouvelle image. L'affichage n'est pas rafraichi.
 */
void ImageMusique::EvtSouris(wxMouseEvent &event)
{
    wxFileDialog navig(NULL, _("Choisissez une image"), wxStandardPaths::Get().GetDocumentsDir(), "", "Image (*.jpg;*.jpeg)|*.jpg;*.jpeg", wxFD_OPEN | wxFD_FILE_MUST_EXIST);
    int ouvert = navig.ShowModal();

    if (ouvert == wxID_OK)
        LectureImageEvent(navig.GetPath());
}

/**
 * Lit une image se trouvant � l'adresse chaine. Si la lecture r�ussi, la fen�tre parente en est inform�e
 * @param chaine le nom complet de l'image
 */
void ImageMusique::LectureImageEvent(wxString chaine)
{
    if (m_image.LoadFile(chaine))
    {
        wxCommandEvent evt(wxEVT_IMAGE_SELECTION, GetId());
        evt.SetString(chaine);
        GetParent()->GetEventHandler()->AddPendingEvent(evt);
    }
}

/**
 * @class DropFichierImage
 * @brief Permet un Drag&Drop de fichier venant de l'ext�rieur sur ImageMusique
 */

/**
 * Constructeur
 * @param imageMusique l'objet associ�
 */
DropFichierImage::DropFichierImage(ImageMusique *imageMusique)
{    m_imageMusique = imageMusique;}

/**
 * Destructeur
 */
DropFichierImage::~DropFichierImage()
{}

/**
 * Appel� lors d'un Drag&Drop sur l'�l�ment associ�
 * @param x l'abscisse du point de rel�chement
 * @param y l'ordonn�e du point de rel�chement
 * @param filenames un tableau contenant des noms � essayer
 * @return vrai si une image a pu �tre trouv�e, faux sinon
 */
bool DropFichierImage::OnDropFiles(wxCoord x, wxCoord y, const wxArrayString& filenames)
{
    size_t max = filenames.GetCount(), i = 0;
    bool continuer = true;
    wxLogMessage(filenames.Item(i));

    while (i<max && continuer)
    {
        if (filenames.Item(i).Lower().EndsWith(".jpg") || filenames.Item(i).Lower().EndsWith(".bmp"))
        {
            m_imageMusique->LectureImageEvent(filenames.Item(i));
            continuer = false;
        }
        i++;
    }
    return !continuer;
}


////////////////////////////////////////////////////////
/**
 * @class ImagePochette
 * @brief Composant affichant une image, acceptant le Drag & Drop, et ouvre le navigateur de fichier pour changer l'image ; lors de tout changement, la fen�tre parente n'est pas inform�e.
 */

BEGIN_EVENT_TABLE(ImagePochette, wxStaticBitmap)
    EVT_LEFT_DCLICK(ImagePochette::EvtSouris)
END_EVENT_TABLE()

/**
 * Constructeur
 * @param Parent la fen�tre parente
 * @param id l'identifiant de l'instance
 * @param label un wxBitmap � modifier
 */
ImagePochette::ImagePochette(wxWindow *Parent, wxWindowID id, wxBitmap label) : wxStaticBitmap(Parent, id, label)
{
    m_pochetteBool = false;
    m_modif = false;
    SetDropTarget(new DropFichierImagePochette(this));
}

/**
 * Desctructeur
 */
ImagePochette::~ImagePochette()
{}

/**
 * Indique si une image est en m�moire
 * @return vrai ou faux
 */
bool ImagePochette::IsVoid()
{    return m_pochetteBool;}

/**
 * Si affiche vaut vrai, l'image est affich� sinon, elle est effac�e
 * @param affiche
 */
void ImagePochette::AfficheImage(bool affiche)
{
    int largeur = 0, hauteur = 0;
    GetSize(&largeur, &hauteur);
    if (affiche && m_image.IsOk())
    {
        m_pochetteBool = true;
        //int lar = m_image.GetWidth(), haut = m_image.GetHeight(), max = 0;
        //max = (lar > haut) ? haut : lar;
        //SetBitmap(wxBitmap(m_image.Size(wxSize(largeur, hauteur), wxPoint(0, 0), 0, 0, 0)));
        SetBitmap(wxBitmap(m_image.Scale(largeur, hauteur)));
    }
    else
    {
        m_image.Destroy();
        m_pochetteBool = false;
        SetBitmap(wxBitmap(wxImage(largeur, hauteur)));
    }
}

/**
 * Retourne l'image
 * @return l'image
 */
wxImage ImagePochette::GetImage()
{    return m_image;}

/**
 * Modifie l'image courante sans modifier l'affichage
 * @param image la nouvelle image
 */
void ImagePochette::SetImage(wxImage image)
{
    m_image = image;
    m_modif = true;
}

/**
 * �v�nement - Affiche une bo�te de dialogue pour s�lectionner une nouvelle image. L'affichage n'est pas rafraichi.
 */
void ImagePochette::EvtSouris(wxMouseEvent &event)
{
    wxFileDialog navig(NULL, _("Choisissez une image"), wxStandardPaths::Get().GetDocumentsDir(), "", "Image (*.jpg;*.jpeg)|*.jpg;*.jpeg", wxFD_OPEN | wxFD_FILE_MUST_EXIST);
    int ouvert = navig.ShowModal();

    if (ouvert == wxID_OK)
        LectureImageEvent(navig.GetPath());
}

/**
 * Lit une image se trouvant � l'adresse chaine. Affichage non rafraichi
 * @param chaine le nom complet de l'image
 */
void ImagePochette::LectureImageEvent(wxString chaine)
{
    if (m_image.LoadFile(chaine))
    {
        AfficheImage(true);
        m_modif = true;
    }
}

/**
 * @class DropFichierImagePochette
 * @brief Permet un Drag&Drop de fichier venant de l'ext�rieur sur ImagePochette
 */

/**
 * Constructeur
 * @param imageMusique l'objet associ�
 */
DropFichierImagePochette::DropFichierImagePochette(ImagePochette *imageMusique)
{    m_imageMusique = imageMusique;}

/**
 * Destructeur
 */
DropFichierImagePochette::~DropFichierImagePochette()
{}

/**
 * Appel� lors d'un Drag&Drop sur l'�l�ment associ�
 * @param x l'abscisse du point de rel�chement
 * @param y l'ordonn�e du point de rel�chement
 * @param filenames un tableau contenant des noms � essayer
 * @return vrai si une image a pu �tre trouv�e, faux sinon
 */
bool DropFichierImagePochette::OnDropFiles(wxCoord x, wxCoord y, const wxArrayString& filenames)
{
    size_t max = filenames.GetCount(), i = 0;
    bool continuer = true;
    wxLogMessage(filenames.Item(i));

    while (i<max && continuer)
    {
        if (filenames.Item(i).Lower().EndsWith(".jpg") || filenames.Item(i).Lower().EndsWith(".bmp"))
        {
            m_imageMusique->LectureImageEvent(filenames.Item(i));
            continuer = false;
        }
        i++;
    }
    return !continuer;
}


