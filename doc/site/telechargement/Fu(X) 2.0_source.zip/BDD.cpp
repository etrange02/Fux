/***************************************************************
 * Name:      BDD.cpp
 * Purpose:   Code for Fu(X) 2.0
 * Author:    David Lecoconnier (etrange02@aol.com)
 * Created:   2011-11-29
 * Copyright: David Lecoconnier (http://www.fuxplay.com)
 * License:
 **************************************************************/
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include "BDD.h"

/**
 * @class BDD
 * @brief Repr�sente la base de donn�es de Fu(X) (ou l'audioth�que)
 */

static BDD* instanceBDD = NULL;

/**
 * Constructeur, ne pas appeler
 * @see BDD::Get()
 */
BDD::BDD()
{
    wxSQLite3Database::InitializeSQLite();
    m_database = new wxSQLite3Database();
    m_database->Open(Parametre::Get()->getRepertoireParametre("fux.bdd"));
    CreerTables();
}

/**
 * Retourne une instance de BDD
 * @return une instance
 */
BDD* BDD::Get()
{
    if (!instanceBDD)
        instanceBDD = new BDD();
    return instanceBDD;
}

/**
 * Ferme la base de donn�es
 */
void BDD::Close()
{
    m_database->Close();
    wxSQLite3Database::ShutdownSQLite();
}

/**
 * Cr�e les diff�rentes tables si celles-ci n'existent pas dans la base de donn�es.
 */
void BDD::CreerTables()
{
    if (!m_database->TableExists("chanson"))
        m_database->ExecuteUpdate("CREATE TABLE chanson(id INTEGER PRIMARY KEY AUTOINCREMENT, nom VARCHAR(255), annee DATE)");
    if (!m_database->TableExists("artiste"))
        m_database->ExecuteUpdate("CREATE TABLE artiste(id INTEGER PRIMARY KEY AUTOINCREMENT, nom VARCHAR(75))");
    if (!m_database->TableExists("album"))
        m_database->ExecuteUpdate("CREATE TABLE album(id INTEGER PRIMARY KEY AUTOINCREMENT, nom VARCHAR(100), annee_parution DATE)");//AAAA-MM-JJ

    if (!m_database->TableExists("produit"))
        m_database->ExecuteUpdate("CREATE TABLE produit(id_chanson INTEGER REFERENCES chanson(id), id_artiste INTEGER REFERENCES artiste(id), PRIMARY KEY(id_chanson, id_artiste))");
    if (!m_database->TableExists("publie"))
        m_database->ExecuteUpdate("CREATE TABLE publie(id_artiste INTEGER REFERENCES artiste(id), id_album INTEGER REFERENCES album(id), PRIMARY KEY(id_artiste, id_album))");
    if (!m_database->TableExists("contient"))
        m_database->ExecuteUpdate("CREATE TABLE contient(id_chanson INTEGER REFERENCES chanson(id), id_album INTEGER REFERENCES album(id), PRIMARY KEY(id_chanson, id_album))");//AAAA-MM-JJ
}



