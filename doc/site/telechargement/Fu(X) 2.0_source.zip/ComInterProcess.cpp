/***************************************************************
 * Name:      ComInterProcess.cpp
 * Purpose:   Code for Fu(X) 2.0
 * Author:    David Lecoconnier (etrange02@aol.com)
 * Created:   2010-06-01
 * Copyright: David Lecoconnier (http://www.fuxplay.com)
 * License:
 **************************************************************/
#include "ComInterProcess.h"


const wxEventType wxEVT_SERVEUR = wxNewEventType();
/**
 * @class TCPConnexionEchangeInstanceLocalHost
 * @brief Repr�sente la connexion client/serveur. �change local de cha�nes de caract�res.
 */
 /**
 * @class TCPClient
 * @brief Repr�sente le client. �change local de cha�nes de caract�res vers le serveur.
 */
 /**
 * @class TCPServeur
 * @brief Repr�sente le serveur. �change local de cha�nes de caract�res en provenance du client.
 */

/////////////////////////////////////////////////
/**
 * Constructeur
 * @param parent fen�tre parente (Serveur uniquement)
 * @param id identifiant de la connexion (Serveur uniquement)
 */
TCPConnexionEchangeInstanceLocalHost::TCPConnexionEchangeInstanceLocalHost(wxWindow *parent, int id) : wxConnection()
{
    m_parent = parent;
    m_id = id;
}

/**
 * C�t� client - Demande l'ex�cution de data donn�e en param�tre.
 * @param data Ligne � ex�cuter
 * @return vrai si r�ussite, faux sinon.
 */
bool TCPConnexionEchangeInstanceLocalHost::Execute(const wxString data)
{    return wxConnection::Execute(data);}

/**
 * C�t� serveur - Demande l'ex�cution de donn�es
 * @param topic
 * @param data
 * @param size
 * @param format
 * @return vrai si r�ussite, faux sinon
 */
bool TCPConnexionEchangeInstanceLocalHost::OnExecute(const wxString& topic, wxChar *data, int size, wxIPCFormat format)//que contient topic ?
{
    if (topic == IPC_TOPIC)
        m_tableau.Add(wxString(data));
    return true;
}

/**
 * C�t� serveur - Demande d'interruption de la connexion. La suppression de la classe est manuelle
 * @return vrai
 */
bool TCPConnexionEchangeInstanceLocalHost::OnDisconnect()
{
    if(m_parent!=NULL)
    {
        wxCommandEvent evt(wxEVT_SERVEUR, m_parent->GetId());
        evt.SetInt(m_id);
        m_parent->GetEventHandler()->AddPendingEvent(evt);
    }
    return true;
}

/**
 * Retourne l'identifiant de la connexion. Utilise seulement du c�t� serveur
 * @return l'identifiant
 */
int TCPConnexionEchangeInstanceLocalHost::GetId()
{
    return m_id;
}

/**
 * Retourne le tableau construit � partir de l'�change d'information entre le client et le serveur. Utilise seulement du c�t� serveur
 * @return le tableau
 */
wxArrayString* TCPConnexionEchangeInstanceLocalHost::GetTableau()
{
    return &m_tableau;
}

///////////////////////////////////////////////
/**
 * Constructeur
 */
TCPClient::TCPClient() : wxClient()
{}

/**
 * Demande la cr�ation d'une connexion
 * @return l'instance de la connexion
 */
wxConnectionBase* TCPClient::OnMakeConnection()
{    return new TCPConnexionEchangeInstanceLocalHost;}


///////////////////////////////////////////////
/**
 * Constructeur
 * @param parent N�cessaire � l'envoi d'�v�nements
 */
TCPServeur::TCPServeur(wxWindow *parent) : wxServer()
{    m_parent = parent; m_connexions = new ArrayOfConnexion(); m_compte = 0;}

/**
 * Destructeur
 */
TCPServeur::~TCPServeur()
{
    if (!m_connexions->IsEmpty())
        m_connexions->Clear();
}

/**
 * Serveur - Cr�e et retourne une connexion si celle-ci est valide
 * @param topic le "type" de connexion
 * @return une instance de la connexion
 */
wxConnectionBase* TCPServeur::OnAcceptConnection(const wxString &topic)
{
    if (topic == IPC_TOPIC)
    {
        TCPConnexionEchangeInstanceLocalHost* c = new TCPConnexionEchangeInstanceLocalHost(m_parent, m_compte++);
        m_connexions->Add(c);
        return c;
    }
    else
    {
        wxLogMessage("Connexion non autoris�e");
        return NULL;
    }
}

/**
 * Serveur - Supprime la connexion dont l'identifiant est id
 * @param id l'identifiant de la connexion � supprimer
 */
void TCPServeur::Deconnecter(int id)
{
    size_t i = 0;
    while (i < m_connexions->GetCount())
    {
        if (m_connexions->Item(i)->GetId() == id)
        {
            m_connexions->Remove(m_connexions->Item(i));
            i = m_connexions->GetCount();
        }
        i++;
    }
}

/**
 * Serveur - Retourne le tableau construit par la connexion n�id
 * @param id l'identifiant de la connexion
 * @return le tableau de caract�res
 */
wxArrayString* TCPServeur::GetConnexionTableau(int id)
{
    size_t i = 0;
    while (i < m_connexions->GetCount())
    {
        if (m_connexions->Item(i)->GetId() == id)
             return m_connexions->Item(i)->GetTableau();
        i++;
    }
    return NULL;
}


