/***************************************************************
 * Name:      FenetreDetachable.cpp
 * Purpose:   Code for Fu(X) 2.0
 * Author:    David Lecoconnier (etrange02@aol.com)
 * Created:   2012-01-23
 * Copyright: David Lecoconnier (http://www.fuxplay.com)
 * License:
 **************************************************************/
#include "FenetreDetachable.h"

/**
 * @class FenetreDetachable
 * @brief Fen�tre qui peut accueillir un panel. On obtient un "panel flottant"
 */

const wxEventType wxEVT_FERMER_FENETRE_DETACHABLE = wxNewEventType();

BEGIN_EVENT_TABLE(FenetreDetachable, wxFrame)
    EVT_CLOSE(FenetreDetachable::Fermer)
END_EVENT_TABLE()

/**
 * Constructeur
 */
FenetreDetachable::FenetreDetachable(wxWindow* parent, wxWindow* page, wxSizer* sizer, int type, int idBouton, wxString titre) : wxFrame(NULL, -1, titre)
{
    m_page = page;
    m_page->Reparent(this);
    m_parent = parent;
    m_type = type;
    m_idBouton = idBouton;

    m_sizer = sizer;
    m_sizer->Show(true);
    SetSizer(m_sizer);
    m_sizer->SetSizeHints(this);
    SetIcon(wxIcon(Parametre::Get()->getRepertoireExecutableLib("play.ico"), wxBITMAP_TYPE_ICO));
}

/**
 * Destructeur
 */
FenetreDetachable::~FenetreDetachable()
{
    Destroy();
}

/**
 * Retourne le panel associ�
 * @return l'instance du panel associ�
 */
wxSizer* FenetreDetachable::GetSizer()
{ return m_sizer; }

/**
 * Assoce un panel
 * @param sizer la panel � associer
 */
void FenetreDetachable::SetSizer(wxSizer* sizer)
{ m_sizer = sizer; }

/**
 * Retourne le type de la fen�tre, correspond � la classe. UTILE ?????
 */
int FenetreDetachable::GetType()
{    return m_type;}

/**
 * Retourne l'identifiant du bouton qui a caus� la cr�ation de cette fen�tre
 */
int FenetreDetachable::GetIdBouton()
{    return m_idBouton;}

/**
 * �v�nement - D�clench� lors d'un clic sur la croix. Envoie un message pour informer de la tentative de suppression. Le but est de r�cup�rer les �l�ments internes. Le �v�nement envoy� contient en entier le type du panel
 * @param event
 */
void FenetreDetachable::Fermer(wxCloseEvent &event)
{
    wxCommandEvent evt(wxEVT_FERMER_FENETRE_DETACHABLE, GetId());
    evt.SetInt(m_type);
    m_parent->GetEventHandler()->AddPendingEvent(evt);
}

/**
 * Permet de remettre le panel dans son �tat d'origine. Renvoie le sizer contenant le panel
 * @return un pointeur vers le sizer de la fen�tre
 */
wxSizer* FenetreDetachable::RetourNormale()
{
    m_page->Reparent(m_parent);
    return m_sizer;
}

