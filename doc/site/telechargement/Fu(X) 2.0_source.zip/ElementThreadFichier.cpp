/***************************************************************
 * Name:      ElementThreadFichier.cpp
 * Purpose:   Code for Fu(X) 2.0
 * Author:    David Lecoconnier (etrange02@aol.com)
 * Created:   2012-01-31
 * Copyright: David Lecoconnier (http://www.fuxplay.com)
 * License:
 **************************************************************/
 #include "ElementThreadFichier.h"

/**
 * @class ElementThreadFichier
 * @brief Repr�sente un �l�ment physique (fichier ou dossier) et l'action qu'il doit subir
 */

/**
 * Constructeur
 * @param nom le nom complet de l'�l�ment
 * @param action l'action � entreprendre (COPIE, DEPLACE, SUPPRIME)
 * @param destination le r�pertoire de destination o� doit d'effectuer l'action
 */
ElementThreadFichier::ElementThreadFichier(wxString nom, int action, wxString destination)
{
    m_nom = nom;
    m_action = action;
    m_destination = destination;
}

/**
 * Destructeur
 */
ElementThreadFichier::~ElementThreadFichier()
{}

/**
 * Retourne le nom de complet l'�l�ment
 * @return le nom de l'�l�ment
 */
wxString& ElementThreadFichier::GetNom()
{
    return m_nom;
}

/**
 * Retourne l'action � faire
 * @return l'action � entreprendre
 */
int ElementThreadFichier::GetAction()
{
    return m_action;
}

/**
 * Compare si l'action � effectuer est celle donn� en param�tre
 * @param action le type d'action � comparer
 * @return vrai si �galit�, faux sinon
 */
bool ElementThreadFichier::IsAction(int action)
{
    return (m_action == action);
}

/**
 * Renvoi le r�pertoire de destination de l'�l�ment. Il peut �tre nul.
 * @return le r�pertoire de destination
 */
wxString& ElementThreadFichier::GetDestination()
{
    return m_destination;
}
