/***************************************************************
 * Name:      DnDCible.cpp
 * Purpose:   Code for Fu(X) 2.0
 * Author:    David Lecoconnier (etrange02@aol.com)
 * Created:   2012-06-26
 * Copyright: David Lecoconnier (http://www.fuxplay.com)
 * License:
 **************************************************************/
#include "DnDCible.h"

/**
 * @class DnDCible
 * @brief Repr�sente la cible d'un Drag&Drop pour une wxListCtrl
 */

/**
 * Constructeur
 * @param liste la liste cible
 */
DnDCible::DnDCible(wxListCtrl *liste) : wxDropTarget(new DnDBufferData)
{
    m_liste = liste;
    m_pageGestion = NULL;
}

/**
 * Constructeur
 * @param liste la liste cible
 * @param pageGestion la fen�tre parente de la liste cible (c'est elle qui traite les informations)
 */
DnDCible::DnDCible(wxListCtrl *liste, wxWindow* pageGestion) : wxDropTarget(new DnDBufferData)
{
    m_liste = liste;
    m_pageGestion = (PageGestionPeriph*) pageGestion;
}

/**
 * Surcharge
 */
wxDragResult DnDCible::OnDragOver(wxCoord x, wxCoord y, wxDragResult def)
{   return (def == wxDragMove ? wxDragCopy : def);}

/**
 * Surcharge - Traitement d'un �v�nement de Drag&Drop
 * @param x l'abscisse du rel�ch�
 * @param y l'ordonn�e du rel�ch�
 * @param def
 */
wxDragResult DnDCible::OnData(wxCoord x, wxCoord y, wxDragResult def)
{
    if (!GetData())
        return wxDragNone;

    DnDListeFichier* TransFile;
    TransFile = ((DnDBufferData *)GetDataObject())->GetTransFile();

    if (m_pageGestion == NULL)
    {
        if (TransFile->Item(0).IsNumber())
            Musique::Get()->PlacerLigneInt(TransFile->arrayString(), GetPositionCoord(y), true);
        else
            Musique::Get()->PlacerLigneString(TransFile->arrayString(), GetPositionCoord(y), true);//Les coordonn�es commencent au coin sup gauche de la liste, dans les en-t�tes
    }
    else
        m_pageGestion->GlisserTraitement(TransFile->arrayString(), GetPositionCoord(y));//Les coordonn�es commencent au coin sup gauche de la liste, dans les en-t�tes

    TransFile->Clear();
    return wxDragCopy;
}

/**
 * Calcul la position du premier �l�ment en fonction de ce qui est affich� dans la liste
 * @param y la coordonn�e en pixels
 * @return l'indice de d�but de DnD
 */
long DnDCible::GetPositionCoord(int y)
{
    long pos = 0, i = m_liste->GetItemCount(), min = m_liste->GetTopItem();
    bool continuer = true;
    wxPoint point;
    //position du dernier item visible
    if (i < m_liste->GetCountPerPage() ||i == (m_liste->GetCountPerPage() + min))//Le dernier item est visible
    {
        wxRect rect;
        m_liste->GetItemRect(i-1, rect);//emplacement physique du dernier item
        if (rect.GetY() + rect.GetHeight() < y)//le rel�chement de la souris est apr�s le dernier item
            return i;
        pos = m_liste->GetItemCount();
    }
    else
        pos = min + m_liste->GetCountPerPage();

    while ((i > 0 && pos >= min) && continuer)//Recherche la position par rapport au bord sup�rieur de la case
    {
        pos--;
        m_liste->GetItemPosition(pos, point);
        if (y>point.y)
            continuer = false;
        i--;
    }
    return pos;
}
