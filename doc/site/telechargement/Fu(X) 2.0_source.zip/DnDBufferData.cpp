/***************************************************************
 * Name:      DnDBufferData.cpp
 * Purpose:   Code for Fu(X) 2.0
 * Author:    David Lecoconnier (etrange02@aol.com)
 * Created:   2012-06-26
 * Copyright: David Lecoconnier (http://www.fuxplay.com)
 * License:
 **************************************************************/
#include "DnDBufferData.h"

/**
 * @class DnDBufferData
 * @brief Traduit un DnDListeFichier en une cha�ne compatible avec le buffer. Cette classe repr�sente les �l�ments en d�placement
 */

/**
 * Constructeur
 * @param dndNom un tableau de cha�nes
 */
DnDBufferData::DnDBufferData(DnDListeFichier* dndNom)
{
   if (dndNom)  // Si aucun objet donn�e n'est fourni en cr�er un
      m_DndNomObjet = new DnDListeFichier(*dndNom);
   else
      m_DndNomObjet = 0;

   wxDataFormat transfileformat; // Positionner l'identifiant du format
   transfileformat.SetId("DnDBufferData");
   SetFormat(transfileformat);
}

/**
 * Destructeur
 */
DnDBufferData::~DnDBufferData()
{    delete m_DndNomObjet;}

/**
 * Calcul la taille que prendra le tampon apr�s transformation du DnDListeFichier (tableau de cha�nes) en une chaine
 */
size_t DnDBufferData::GetDataSize() const
{
   size_t ret = 0, count;

   if (m_DndNomObjet)  // V�rification de l'existance d'un objet donn�e
   {  // Chemin et noms de fichiers s�par�s par \n
      count = m_DndNomObjet->GetCount();
      ret += count;  // On ajoute count caract�re \n
      for (size_t i = 0; i < count; i++)
         ret += m_DndNomObjet->Item(i).Len();
   }
   else
      ret = 0;
   return ret;
}

/**
 * Transforme un DnDListeFichier (tableau de cha�nes) en une cha�ne
 * @param buf un tableau de type void qui sera remplie par la m�thode
 * @return true si la conversion a pu se faire, faux sinon
 */
bool DnDBufferData::GetDataHere(void *buf) const
{
   if (m_DndNomObjet)  // V�rification de l'existance d'un objet donn�e
   {
      wxString tmp;
      size_t count = m_DndNomObjet->GetCount();
      for (size_t i = 0; i < count; i++)  // les autres sont les noms de fichiers
         tmp += m_DndNomObjet->Item(i) + _T("\n");
      memcpy(buf, tmp.c_str(), tmp.Len());
      return true;
   }
   return false;
}

/**
 * Transforme un tableau de type void (buf) en DnDListeFichier (tableau de cha�nes)
 * @param len la taille du buffer
 * @param buf le buffer
 * @return vrai si la conversion a pu se faire
 */
bool DnDBufferData::SetData(size_t len, const void* buf)
{
    if (len != 0)
    {
        wxString tmp1, tmp2;

        if (!m_DndNomObjet) // Cr�er un objet donn�e si inexistant
            m_DndNomObjet = new DnDListeFichier;
        tmp1 = wxString((const char*)buf, len);
        m_DndNomObjet->Clear();

        while (!tmp1.IsEmpty())
        {
            tmp2 = tmp1.BeforeFirst(_T('\n'));  // d�coupage du tampon � chaque \n
            tmp1 = tmp1.AfterFirst(_T('\n'));
            if (!tmp2.IsEmpty())
                m_DndNomObjet->AddFile(tmp2);   // Les autres sont les noms de fichiers
        }
    }
   return true;
}

/**
 * Retourne le tableau de cha�nes associ�
 * @return le tableau
 */
DnDListeFichier* DnDBufferData::GetTransFile()
{    return m_DndNomObjet;}

