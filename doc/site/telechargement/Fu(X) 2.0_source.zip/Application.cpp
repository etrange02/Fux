/***************************************************************
 * Name:      Application.cpp
 * Purpose:   Code for Fu(X) 2.0
 * Author:    David Lecoconnier (etrange02@aol.com)
 * Created:   2009-07-25
 * Copyright: David Lecoconnier (http://www.fuxplay.com)
 * License:
 **************************************************************/
#include "wx/wxprec.h"

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "Application.h"

/**
 * @class wxFuXApp
 * @brief Classe application du programme, "contient la fonction main"
 */

BEGIN_EVENT_TABLE(wxFuXApp, wxApp)
    EVT_END_SESSION(wxFuXApp::Fermer)
END_EVENT_TABLE()

/**
 * Surcharge. Appel� au lancement de l'application
 * @return Vrai si succ�s.
 */
bool wxFuXApp::OnInit()
{
    // Gestion de la langue
    //TraductionInternationale();

    m_checker = new wxSingleInstanceChecker("Fu(X)" + wxGetUserId());
    if (m_checker->IsAnotherRunning())
    {
        if (argc >= 2)
            EnvoiStringAutreInstance();
        else
            wxLogError(_("Fu(X) est d�j� ouvert, proc�dure d'ouverture annul�e"));//"Another program instance is already running, aborting."));

        delete m_checker; // OnExit() won't be called if we return false
        m_checker = NULL;

        return false;
    }
    else
    {
        //Parametre::Get();
        FichierLog::Get()->Ajouter("D�marrage de l'application, param�tre : " + wxString(argc >= 2 ? argv[1] : "NULL"));
        m_fenetre = new FuXFenetre(argc, argv);
        m_fenetre->Show(true);

        return true;
    }
}

/**
 * Surcharge. Appel� � la fermeture de l'application
 * @return 0 si aucun probl�me
 */
int wxFuXApp::OnExit()
{
    delete m_checker;
    FichierLog::Get()->Ajouter("Fin de l'application");
    FichierLog::Get()->~FichierLog();
    return 0;
}

/**
 * Envoi � une autre instance du programme les cha�nes donn�es en argument
 */
void wxFuXApp::EnvoiStringAutreInstance()
{
    TCPClient *client = new TCPClient();
    TCPConnexionEchangeInstanceLocalHost *connexion = (TCPConnexionEchangeInstanceLocalHost*) client->MakeConnection(IPC_HOST, IPC_SERVICE, IPC_TOPIC);
    wxFileName chaine;

    if (connexion)
    {
        for (int i = 1; i<argc; i++)
        {
            chaine = argv[i];
            chaine.Normalize(wxPATH_NORM_SHORTCUT);
            if (Parametre::Get()->islisable(chaine.GetFullPath().AfterLast('.').Lower()))
            {
                if (!connexion->Execute(chaine.GetFullPath()))
                    wxLogMessage("Erreur lors de l'envoie du titre � l'application principale : \n" + chaine.GetFullPath());
            }
            else
                wxLogMessage("L'extension " + chaine.GetExt() + " n'est pas prise en compte");
        }
        connexion->Disconnect();
        delete connexion;
    }
    else
        wxLogMessage("Impossible d'envoyer le titre � l'application principale\n" + chaine.GetFullPath());
    delete client;
}

/**
 * Traduction automatique de l'application dans une langue �trang�re
 */
void wxFuXApp::TraductionInternationale()
{
    // Ajout des pr�fixes possibles de chemins d'acc�s aux catalogues
    wxLocale::AddCatalogLookupPathPrefix(wxT("."));
    wxLocale::AddCatalogLookupPathPrefix(wxT(".."));
    wxLocale::AddCatalogLookupPathPrefix(_T("locale"));
    // Mise en place de la langue par d�faut du syst�me
    m_local.Init(wxLANGUAGE_DEFAULT);
    {
        wxLogNull noLog; // Supprime les erreurs si les catalogues n'existent pas
        // Catalogue de l'application
        m_local.AddCatalog(_T("Fu(X)"));
        // Catalogue de wxWidgets
        m_local.AddCatalog(_T("wxstd"));
    }
}

/**
 * Appel� en cas de fermeture de session, arr�t du programme avant de se faire tuer !
 */
void wxFuXApp::Fermer(wxCloseEvent &event)
{
    m_fenetre->Close(true);
}

IMPLEMENT_APP(wxFuXApp);
