/***************************************************************
 * Name:      fuxHTMLindex.h
 * Purpose:   Code for Fu(X) 2.0
 * Author:    David Lecoconnier (etrange02@aol.com)
 * Created:   2012-01-18
 * Copyright: David Lecoconnier (http://www.fuxplay.com)
 * License:
 **************************************************************/

/* Page d'accueil de la doc */

/** \mainpage
 * <h2> Qu'est-ce que Fu(X)</h2>
 * <p>Fu(X) est un lecteur audio mp3.
   Il devrait � terme g�rer plusieurs extensions comme .wma et .m4a pour ne citer qu'eux !
   Il permet d'�diter les TAGs des titres, ajouter une pochette d'album.</p>
 *
 * <h2> A faire</h2>
 * <p><ul>
 * <li><i>Remplacer les listes cha�n�es par des wxArray</i> -- Fait</li>
 * <li><i>Doc de l'application</i> -- Fait</li>
 * <li>Remplacer la structure des fichiers sauve par du XML</li>
 * <li><i>Unifier les classes TCPConnexionClient et TCPConnexionServeur</i> -- Fait</li>
 * <li>Mettre en place la BDD</li>
 * <li>...</li>
 * <li>Garder quelques surprises !</li>
 * </ul></p>
 *
 * <a href="..">Page principale</a>
 */

#ifndef FUXHTMLINDEX_H_INCLUDED
#define FUXHTMLINDEX_H_INCLUDED



#endif // FUXHTMLINDEX_H_INCLUDED
