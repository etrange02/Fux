#ifndef OS_WIN_H_INCLUDED
#define OS_WIN_H_INCLUDED

#include <wx/wx.h>

bool CreationRaccourci(wxString cheminRaccourci, wxString cheminOrigine);

#endif // OS_WIN_H_INCLUDED
