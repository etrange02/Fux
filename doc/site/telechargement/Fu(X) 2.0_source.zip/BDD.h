#ifndef BDD_H_INCLUDED
#define BDD_H_INCLUDED

#include <wx/wx.h>
//#include <wx/wxsqlite3.h>
#include "Parametre.h"
#include "wxsqlite3.h"

/*
Pour compiler, il faut placer les ent�tes de wxsqlite3 dans le dossier d'installation de wxWidgets.
Un simple copier-colle de include dans include suffit !
*/

class BDD
{
    public:
        BDD();
        static BDD* Get();
        void Close();
        void CreerTables();

    protected:
        wxSQLite3Database *m_database;
};

#endif // BDD_H_INCLUDED
