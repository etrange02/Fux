#ifndef IMAGEFICHIERMUSIQUE_H_INCLUDED
#define IMAGEFICHIERMUSIQUE_H_INCLUDED

#include <wx/wx.h>
#include <wx/stdpaths.h>
#include <wx/dir.h>
#include <wx/dnd.h>
#include "Define.h"

extern const wxEventType wxEVT_IMAGE_SELECTION;

class ImageMusique : public wxStaticBitmap
{
    public:
        ImageMusique(wxWindow*, wxWindowID, wxBitmap);
        ImageMusique(wxWindow*, wxWindowID);
        ~ImageMusique();
        void AfficheImage(bool);
        wxImage GetImage();
        void SetImage(wxImage);
        void EvtSouris(wxMouseEvent&);
        void LectureImageEvent(wxString);

    private:
        bool m_pochetteBool, m_redimension;
        wxImage m_image;

    DECLARE_EVENT_TABLE()
};

class DropFichierImage : public wxFileDropTarget
{
    public:
        DropFichierImage(ImageMusique *imageMusique);
        virtual ~DropFichierImage();
        bool OnDropFiles(wxCoord x, wxCoord y, const wxArrayString& filenames);

    protected:
        ImageMusique *m_imageMusique;
};

class ImagePochette : public wxStaticBitmap
{
    public:
        ImagePochette(wxWindow*, wxWindowID, wxBitmap);
        ImagePochette(wxWindow*, wxWindowID);
        ~ImagePochette();
        void AfficheImage(bool);
        wxImage GetImage();
        void SetImage(wxImage);
        void EvtSouris(wxMouseEvent&);
        void LectureImageEvent(wxString);
        bool IsVoid();

    private:
        bool m_pochetteBool, m_modif;
        wxImage m_image;

    DECLARE_EVENT_TABLE()
};

class DropFichierImagePochette : public wxFileDropTarget
{
    public:
        DropFichierImagePochette(ImagePochette *imageMusique);
        virtual ~DropFichierImagePochette();
        bool OnDropFiles(wxCoord x, wxCoord y, const wxArrayString& filenames);

    protected:
        ImagePochette *m_imageMusique;
};

#endif // IMAGEFICHIERMUSIQUE_H_INCLUDED
