/***************************************************************
 * Name:      Fenetre.cpp
 * Purpose:   Code for Fu(X) 2.0
 * Author:    David Lecoconnier (etrange02@aol.com)
 * Created:   2009-07-24
 * Copyright: David Lecoconnier (http://www.fuxplay.com)
 * License:
 **************************************************************/
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include "Fenetre.h"

/**
 * @class FuXFenetre
 * @brief Interface principale de l'application : barre de menu. Elle contient plusieurs wxSizer.
 */

BEGIN_EVENT_TABLE(FuXFenetre, wxFrame)
    EVT_MENU(ID_APP_BAR_QUITTER, FuXFenetre::Quitter)
    EVT_MENU(ID_APP_BAR_LECTURE, FuXFenetre::Lecture)
    EVT_MENU(ID_APP_BAR_SUIVANT, FuXFenetre::Suivant)
    EVT_MENU(ID_APP_BAR_PRECEDENT, FuXFenetre::Precedent)
    EVT_MENU(ID_APP_BAR_STOP, FuXFenetre::Stop)
    EVT_MENU(ID_APP_BAR_REPETE, FuXFenetre::Repete)
    EVT_MENU(ID_APP_BAR_ALEATOIRE, FuXFenetre::Aleatoire)
    EVT_MENU(ID_APP_BAR_OUVRIR, FuXFenetre::OuvrirChanson)
    EVT_MENU(ID_APP_BAR_CHARGER_M3U, FuXFenetre::OuvrirM3U)
    EVT_MENU(ID_APP_BAR_CREER_PLAYLIST, FuXFenetre::SauvegardeListeLecture)
    EVT_MENU(ID_APP_BAR_SUPPRIMER, FuXFenetre::SupprimerListe)
    EVT_MENU(ID_APP_BAR_MAJ_PLAYLIST, FuXFenetre::MAJplaylist)
    EVT_MENU(ID_APP_BAR_A_PROPOS, FuXFenetre::MenuAbout)
    EVT_MENU(ID_APP_BAR_SITE_INTERNET, FuXFenetre::MenuSiteWeb)
    EVT_MENU(ID_APP_BAR_AIDE, FuXFenetre::MenuAide)
    EVT_MENU(ID_APP_BAR_COULEUR_NOUVEL_ENSEMBLE, FuXFenetre::AffichCouleurNouv)
    EVT_MENU(ID_APP_BAR_COULEUR_MODIFIER_APPLIQ_JEU, FuXFenetre::AffichCouleurMod)
    EVT_MENU(ID_APP_BAR_SON_NOUVEL_ENSEMBLE, FuXFenetre::AffichSonNouv)
    EVT_MENU(ID_APP_BAR_SON_MODIFIER_APPLIQ_JEU, FuXFenetre::AffichSonMod)
    EVT_MENU(ID_APP_BAR_DEFAUT, FuXFenetre::AfficheDefaut)
    EVT_BUTTON(ID_APP_AFF_BOUTON_PRECEDENT, FuXFenetre::Precedent)//////////////////////
    EVT_BUTTON(ID_APP_AFF_BOUTON_SUIVANT, FuXFenetre::Suivant)//////////////////////
    EVT_BUTTON(ID_APP_AFF_BOUTON_SUPPRIMER, FuXFenetre::SupprimerListe)//////////////////////
    EVT_BUTTON(ID_APP_AFF_BOUTON_LECTURE, FuXFenetre::BoutonLecture)//////////////////////
    EVT_BUTTON(ID_APP_AFF_PRINCIPAL, FuXFenetre::AffichePrincipal)
    EVT_BUTTON(ID_APP_AFF_PREFERENCE, FuXFenetre::AffichePreference)
    EVT_BUTTON(ID_APP_AFF_EXTRACTEUR, FuXFenetre::AfficheEncodage)
    EVT_BUTTON(ID_APP_AFF_PLAYIST, FuXFenetre::AfficheListeDeLecture)
    EVT_BUTTON(ID_APP_AFF_MODULE_IPOD, FuXFenetre::AfficheGestPeriph)
    EVT_COMMAND_SCROLL(ID_APP_SLIDER_SON, FuXFenetre::ModifSon)
    EVT_MUSIQUE_CHANGE(wxID_ANY, FuXFenetre::ChangementChanson)
    EVT_MUSIQUE_MAJ(wxID_ANY, FuXFenetre::MAJplaylist)
    EVT_MUSIQUE_LECTURE(wxID_ANY, FuXFenetre::BoutonChangeImage)
    EVT_SERVEUR(wxID_ANY, FuXFenetre::EvtServeurAjout)
    EVT_MUSIQUE_GRAPH(wxID_ANY, FuXFenetre::OnTitreChange)
    EVT_MUSIQUE_SUPPRESSION(wxID_ANY, FuXFenetre::SupprimerListe)
    EVT_CHAR_HOOK(FuXFenetre::OnKeyDownRaccourci)
    EVT_BOUTON_FENETRE_DETACHABLE(wxID_ANY, FuXFenetre::SeparationPanel)
    EVT_FERMER_FENETRE_DETACHABLE(wxID_ANY, FuXFenetre::ReunionPanel)
END_EVENT_TABLE()

/**
 * Constructeur
 * @param argc Entier indiquant la taille du tableau
 * @param argv Tableau de caract�res
 */
FuXFenetre::FuXFenetre(int argc, wxChar **argv) : wxFrame(NULL, wxID_ANY, _T("Fu(X) 2.0"))
{
    m_FenetreActuel = PRINCIPAL;
    m_nouvelleFenetre = PRINCIPAL;
    sizerPrincipalH = new wxBoxSizer(wxHORIZONTAL);
    sizerGaucheV = new wxBoxSizer(wxVERTICAL);
    sizerPrincipalH->Add(sizerGaucheV, 0, wxALL | wxEXPAND, 0);
    m_MAJliste = false;

    ConstructionBarre();
    ConstructionSizerGauche();

    Initialisation();
    CreerPages();

    SetSizer(sizerPrincipalH);
    sizerPrincipalH->SetSizeHints(this);

    LecturePreference(argc <= 1);



    if (argc > 1)
    {
        wxFileName fichierMem(argv[1]);
        fichierMem.Normalize(wxPATH_NORM_SHORTCUT);
        if (fichierMem.GetExt().Lower() == "m3u")
        {
            wxTextFile test(fichierMem.GetFullPath()); test.Open();
            if (test.IsOpened())
            {
                if (test.GetLineCount() > 1)
                {
                    m_chanson->CopieFichier(fichierMem.GetFullPath());
                    m_chanson->ChangementChanson();
                    m_MAJliste = true;
                }
                else wxLogMessage(_("Impossible d'ouvrir le fichier, celui-ci est vierge !"));
                test.Close();
            }
        }
        else if (Parametre::Get()->islisable(fichierMem.GetExt().Lower()))
        {
            m_chanson->Lecture(fichierMem.GetFullPath());
            m_chanson->Listage();
            m_MAJliste = true;
        }
    }

    SetIcon(wxIcon(Parametre::Get()->getRepertoireExecutableLib("play.ico"), wxBITMAP_TYPE_ICO));

    m_TimerGraph.setMusique();
    if (m_MAJliste)
        m_playList->GetListeLecture()->MAJ();

    ChangeFenetre();
    m_serveur = new TCPServeur(this);
    if (!m_serveur->Create(IPC_SERVICE))
        wxLogMessage("Impossible d'initialiser le serveur");

    m_fenetresDetachables = new ArrayFenetreDetachable();
    FichierLog::Get()->Ajouter("Fin de FuXFenetre::FuXFenetre(int argc, wxChar **argv)");
}

/**
 * Destructeur
 */
FuXFenetre::~FuXFenetre()
{
    //m_fenetresDetachables->Vider();
    delete m_fenetresDetachables;
    delete m_serveur;
    m_TimerGraph.Stop();
    delete[] m_imageBouton;
}

/**
 * Initialise les instances des classes n�cessaire au lancement de Fu(X)
 */
void FuXFenetre::Initialisation()
{
    FichierLog::Get()->Ajouter("D�but de FuXFenetre::Initialisation");

    int args[] = {WX_GL_RGBA, WX_GL_DOUBLEBUFFER, WX_GL_DEPTH_SIZE, 16, 0};
    m_chanson = new Musique(this);
    m_musiqueGraph = new MusiqueGraph(this, args);
    m_playList = new PlayList;
    m_periph = new GestPeriph;

    BDD::Get()->Close();

    FichierLog::Get()->Ajouter("Fin de FuXFenetre::Initialisation");
}

/**
 * Attache les panels � la fen�tre principal
 */
void FuXFenetre::CreerPages()
{
    FichierLog::Get()->Ajouter("FuXFenetre::CreerPages() - Cr�ation des onglets et des pages manquantes");

    sizerDroitPrincipal = new wxBoxSizer(wxVERTICAL);
    m_TimerGraph.Start(70, false);

    sizerDroitPrincipal->Add(m_musiqueGraph, 1, wxEXPAND, 0);
    sizerDroitPrincipal->Show(m_musiqueGraph);
    sizerDroitPrincipal->Layout();
    FichierLog::Get()->Ajouter("FuXFenetre::CreerPages() - Graphe");
    ///////////////////////////////////////////////////////
    sizerDroitPreference = new wxBoxSizer(wxVERTICAL);
    NotebookPreference = new wxNotebook(this, -1);

    m_pageCouleur.Create(NotebookPreference, -1);
    m_pageCouleur.Creer();

    m_pageSon.Create(NotebookPreference, -1);
    m_pageSon.Creer();

    m_pageDefaut.Create(NotebookPreference, -1);
    m_pageDefaut.Creer();

    NotebookPreference->AddPage(&m_pageCouleur, _("Couleur"));
    NotebookPreference->AddPage(&m_pageSon, _("Son"));
    NotebookPreference->AddPage(&m_pageDefaut, _("D�faut"));

    sizerDroitPreference->Add(NotebookPreference, 1, wxEXPAND, 0);
    sizerDroitPreference->Show(NotebookPreference);
    sizerDroitPreference->Layout();
    FichierLog::Get()->Ajouter("FuXFenetre::CreerPages() - Pr�f�rences");
    //////////////////////////////////////////////////////////////
    sizerDroitExtracteur = new wxBoxSizer(wxVERTICAL);
    wxButton *bouton2 = new wxButton(this, wxID_ANY, _("Extraction indisponible pour le moment"));

    sizerDroitExtracteur->Add(bouton2, 1, wxALL | wxEXPAND, 0);
    sizerDroitExtracteur->Show(bouton2);
    sizerDroitExtracteur->Layout();
    FichierLog::Get()->Ajouter("FuXFenetre::CreerPages() - Extraction");
    /////////////////////////////////////////////////////////////
    sizerDroitPlayist = new wxBoxSizer(wxVERTICAL);
    m_playList->Creer(this, m_MAJliste);

    sizerDroitPlayist->Add(m_playList, 1, wxALL | wxEXPAND, 0);
    sizerDroitPlayist->Show(m_playList);
    sizerDroitPlayist->Layout();
    FichierLog::Get()->Ajouter("FuXFenetre::CreerPages() - Playlist");
    ////////////////////////////////////////////////////////////////////
    sizerDroitIPod = new wxBoxSizer(wxVERTICAL);
    m_periph->Creer(this);

    sizerDroitIPod->Add(m_periph, 1, wxALL | wxEXPAND, 0);
    sizerDroitIPod->Show(m_periph);
    sizerDroitIPod->Layout();
    //////////////////////////////////////////////////////////////////////

    sizerDroit = new wxBoxSizer(wxVERTICAL);
    sizerDroit->SetMinSize(512, 256);
    sizerPrincipalH->Add(sizerDroit, 1, wxALL | wxEXPAND, 0);

    sizerDroit->Add(sizerDroitPrincipal, 1, wxALL | wxEXPAND, 0);
    sizerDroit->Add(sizerDroitPreference, 1, wxALL | wxEXPAND, 0);//2
    sizerDroit->Add(sizerDroitExtracteur, 1, wxALL | wxEXPAND, 0);
    sizerDroit->Add(sizerDroitPlayist, 1, wxALL | wxEXPAND, 0);
    sizerDroit->Add(sizerDroitIPod, 1, wxALL | wxEXPAND, 0);

    m_panelsAssocies = new bool[5];//{true, true, true, true, true};
    for (int i = 0; i < 5 ; i++)
        m_panelsAssocies[i] = true;

    sizerDroitPrincipal->SetMinSize(512, 292);
    sizerDroitPreference->SetMinSize(512, 256);
    sizerDroitExtracteur->SetMinSize(512, 256);
    sizerDroitPlayist->SetMinSize(512, 256);
    sizerDroitIPod->SetMinSize(512, 256);

    sizerDroit->Hide(sizerDroitPreference);
    sizerDroit->Hide(sizerDroitExtracteur);
    sizerDroit->Hide(sizerDroitPlayist);
    sizerDroit->Hide(sizerDroitIPod);
    FichierLog::Get()->Ajouter("FuXFenetre::CreerPages() - Fin");
}

/**
 * Construit la barre de menu
 */
void FuXFenetre::ConstructionBarre()
{
    FichierLog::Get()->Ajouter("FuXFenetre::ConstructionBarre");
    menuFichier = new wxMenu;
    menuFichier->Append(ID_APP_BAR_OUVRIR, _("Ouvrir"));
    menuFichier->Append(ID_APP_BAR_CHARGER_M3U, _("Charger une playlist"));
    menuFichier->Append(ID_APP_BAR_CHARGER_MATIN, _("Charger un .matin"));
    menuFichier->Enable(ID_APP_BAR_CHARGER_MATIN, false);
    menuFichier->AppendSeparator();
    menuFichier->Append(ID_APP_BAR_CREER_PLAYLIST, _("Enregistrer la liste de lecture\tCtrl-S"));//"));//
    menuFichier->Append(ID_APP_BAR_CREER_MATIN, _("Cr�er un fichier matin"));
    menuFichier->Enable(ID_APP_BAR_CREER_MATIN, false);
    menuFichier->AppendSeparator();
    menuFichier->Append(ID_APP_BAR_QUITTER, _("Quitter Fu(X)\tCtrl-Q"));//"));//

    menuPreferences = new wxMenu;
    menuCouleur = new wxMenu;
    menuCouleur->Append(ID_APP_BAR_COULEUR_NOUVEL_ENSEMBLE, _("Nouveau jeu de couleur"));
    menuCouleur->Append(ID_APP_BAR_COULEUR_MODIFIER_APPLIQ_JEU, _("Modifier/Appliquer un jeu de couleur existant"));
    menuSon = new wxMenu;
    menuSon->Append(ID_APP_BAR_SON_NOUVEL_ENSEMBLE, _("Nouvel ensemble audio"));
    menuSon->Append(ID_APP_BAR_SON_MODIFIER_APPLIQ_JEU, _("Modifier/Appliquer une pr�s�lection audio"));
    menuPreferences->AppendSubMenu(menuCouleur, _("Couleur"));
    menuPreferences->AppendSubMenu(menuSon, _("Son"));
    menuPreferences->Append(ID_APP_BAR_DEFAUT, _("D�faut"));

    menuExtraction = new wxMenu;
    menuExtraction->Append(ID_APP_BAR_EXTRACTION, _("Extration de CD"));
    menuExtraction->Enable(ID_APP_BAR_EXTRACTION, false);
    menuExtraction->Append(ID_APP_BAR_MAJ_PLAYLIST, _("MAJ Liste de lecture"));
    //menuExtraction->AppendCheckItem(ID_APP_BAR_FENETRE_GRAPH, _("Fenetre graph"));
    //menuExtraction->Enable(ID_APP_BAR_FENETRE_GRAPH, false);

    menuAide = new wxMenu;
    menuAide->Append(ID_APP_BAR_AIDE, _("Aide\tF1"));//"));//
    menuAide->Append(ID_APP_BAR_SITE_INTERNET, _("Site internet"));
    menuAide->Append(ID_APP_BAR_A_PROPOS, _("A propos"));
    //menuAide->Append(ID_APP_BAR_OBTENIR_EXTENSIONS, _("Obtenir des extensions"));

    menuControle = new wxMenu;
    menuControle->Append(ID_APP_BAR_LECTURE, _("Lecture\tCtrl-P"));//"));//
    menuControle->Append(ID_APP_BAR_STOP, _("Stop"));
    menuControle->AppendSeparator();
    menuControle->Append(ID_APP_BAR_SUIVANT, _("Suivant\tCtrl-RIGHT"));//"));//
    menuControle->Append(ID_APP_BAR_PRECEDENT, _("Pr�c�dent\tCtrl-LEFT"));//"));//
    menuControle->AppendCheckItem(ID_APP_BAR_REPETE, _("R�p�tition"));
    menuControle->AppendCheckItem(ID_APP_BAR_ALEATOIRE, _("Al�atoire"));//\tCtrl-A
    menuControle->AppendSeparator();
    menuControle->Append(ID_APP_BAR_SUPPRIMER, _("Retirer de la liste de lecture\tCtrl-DELETE"));

    menuBarre = new wxMenuBar();
    menuBarre->Append(menuFichier, _("Fichier"));
    menuBarre->Append(menuPreferences, _("Pr�f�rences"));
    menuBarre->Append(menuExtraction, _("Outils"));
    menuBarre->Append(menuAide, _("?"));
    menuBarre->Append(menuControle, _("Contr�les"));


    SetMenuBar(menuBarre);
}

/**
 * Construit la partie gauche de la fen�tre : les 4 raccourcis et les 5 boutons donnant acc�s aux pages
 */
void FuXFenetre::ConstructionSizerGauche()
{
    FichierLog::Get()->Ajouter("FuXFenetre::ConstructionSizerGauche");

    //sizerGaucheV = new wxBoxSizer(wxVERTICAL);
    SliderSon *slide = new SliderSon(this);
    sizerGaucheV->Add(slide, 0, wxUP | wxBOTTOM | wxEXPAND, 5);

    wxGridSizer *sizerBoutonImg = new wxGridSizer(1, 4, 0, 0);
    sizerGaucheV->Add(sizerBoutonImg, 0, wxBOTTOM | wxRIGHT | wxLEFT, 5);
    wxImage::AddHandler(new wxPNGHandler);
    wxImage::AddHandler(new wxJPEGHandler);

    FichierLog::Get()->Ajouter("FuXFenetre::ConstructionSizerGauche - chargement des images");
    m_imageBouton = new wxBitmap[6];
    m_imageBouton[PREC].LoadFile(Parametre::Get()->getRepertoireExecutableLib("prec.png"), wxBITMAP_TYPE_PNG);
    m_imageBouton[LECT].LoadFile(Parametre::Get()->getRepertoireExecutableLib("lect.png"), wxBITMAP_TYPE_PNG);
    m_imageBouton[PAUS].LoadFile(Parametre::Get()->getRepertoireExecutableLib("paus.png"), wxBITMAP_TYPE_PNG);
    m_imageBouton[SUIV].LoadFile(Parametre::Get()->getRepertoireExecutableLib("suiv.png"), wxBITMAP_TYPE_PNG);
    m_imageBouton[SUPPR].LoadFile(Parametre::Get()->getRepertoireExecutableLib("suppr.png"), wxBITMAP_TYPE_PNG);
    m_imageBouton[5].LoadFile(Parametre::Get()->getRepertoireExecutableLib("suppr2.png"), wxBITMAP_TYPE_PNG);

    FichierLog::Get()->Ajouter("FuXFenetre::ConstructionSizerGauche - Application des images aux boutons");
    wxBitmapButton *boutonImage0 = new wxBitmapButton(this, ID_APP_AFF_BOUTON_PRECEDENT, m_imageBouton[PREC], wxDefaultPosition, wxSize(35, 35));
    m_boutonImageLP = new wxBitmapButton(this, ID_APP_AFF_BOUTON_LECTURE, m_imageBouton[LECT], wxDefaultPosition, wxSize(35, 35));
    wxBitmapButton *boutonImage2 = new wxBitmapButton(this, ID_APP_AFF_BOUTON_SUIVANT, m_imageBouton[SUIV], wxDefaultPosition, wxSize(35, 35));
    wxBitmapButton *boutonImage3 = new wxBitmapButton(this, ID_APP_AFF_BOUTON_SUPPRIMER, m_imageBouton[SUPPR], wxDefaultPosition, wxSize(35, 35));
    FichierLog::Get()->Ajouter("FuXFenetre::ConstructionSizerGauche - Fin application des images");

    sizerBoutonImg->Add(boutonImage0, 0, wxALL, 0);
    sizerBoutonImg->Add(m_boutonImageLP, 0, wxALL, 0);
    sizerBoutonImg->Add(boutonImage2, 0, wxALL, 0);
    sizerBoutonImg->Add(boutonImage3, 0, wxALL, 0);


    //wxButton *BoutonG_EcranPrincipal = new wxButton(this, ID_APP_AFF_PRINCIPAL, _("Ecran principal"), wxDefaultPosition, wxSize(140, 38));
    wxButton *BoutonG_EcranPrincipal = new BoutonFenetreDetachable(this, ID_APP_AFF_PRINCIPAL, _("Ecran principal"), wxSize(140, 38), PRINCIPAL);
    sizerGaucheV->Add(BoutonG_EcranPrincipal, 0, wxALL, 5);

    //wxButton *BoutonG_Playist = new wxButton(this, ID_APP_AFF_PLAYIST, _("Liste de lecture"), wxDefaultPosition, wxSize(140, 38));
    wxButton *BoutonG_Playist = new BoutonFenetreDetachable(this, ID_APP_AFF_PLAYIST, _("Liste de lecture"), wxSize(140, 38), LISTELECTURE);
    sizerGaucheV->Add(BoutonG_Playist, 0, wxBOTTOM | wxRIGHT | wxLEFT, 5);

    //wxButton *BoutonG_ModuleIPod = new wxButton(this, ID_APP_AFF_MODULE_IPOD, _("Exploration"), wxDefaultPosition, wxSize(140, 38));
    wxButton *BoutonG_ModuleIPod = new BoutonFenetreDetachable(this, ID_APP_AFF_MODULE_IPOD, _("Exploration"), wxSize(140, 38), GESTIONPERIPH);
    sizerGaucheV->Add(BoutonG_ModuleIPod, 0, wxBOTTOM | wxRIGHT | wxLEFT, 5);

    wxButton *BoutonG_Preferences = new wxButton(this, ID_APP_AFF_PREFERENCE, _("Pr�f�rences"), wxDefaultPosition, wxSize(140, 38));
    sizerGaucheV->Add(BoutonG_Preferences, 0, wxBOTTOM | wxRIGHT | wxLEFT, 5);

    wxButton *BoutonG_ExtracteurMP3 = new wxButton(this, ID_APP_AFF_EXTRACTEUR, _("Encodage"), wxDefaultPosition, wxSize(140, 38));
    sizerGaucheV->Add(BoutonG_ExtracteurMP3, 0, wxBOTTOM | wxRIGHT | wxLEFT, 5);
    BoutonG_ExtracteurMP3->Enable(false);

    sizerGaucheV->SetMinSize(150, 256);
    //sizerPrincipalH->Add(sizerGaucheV, 0, wxALL | wxEXPAND, 0);
}

/**
 * Barre de menu : Page des pr�f�rences, onglet D�faut
 */
void FuXFenetre::AfficheDefaut(wxCommandEvent &WXUNUSED(event))
{
    m_nouvelleFenetre = PREFERENCE;
    ChangeFenetre();
    NotebookPreference->ChangeSelection(2);
}

/**
 * Op�re un basculement sur la page contenant le graphe (page principal)
 */
void FuXFenetre::AffichePrincipal(wxCommandEvent &WXUNUSED(event))
{
    m_nouvelleFenetre = PRINCIPAL;
    ChangeFenetre();
}

/**
 * Op�re un basculement sur la page contenant les pr�f�rences
 */
void FuXFenetre::AffichePreference(wxCommandEvent &WXUNUSED(event))
{
    m_nouvelleFenetre = PREFERENCE;
    ChangeFenetre();
}

/**
 * Op�re un basculement sur la page contenant la gestion de CDs
 */
void FuXFenetre::AfficheEncodage(wxCommandEvent &WXUNUSED(event))
{
    m_nouvelleFenetre = ENCODAGE;
    ChangeFenetre();
}

/**
 * Op�re un basculement sur la page affichant la liste compl�te des titres mis en m�moire
 */
void FuXFenetre::AfficheListeDeLecture(wxCommandEvent &WXUNUSED(event))
{
    m_nouvelleFenetre = LISTELECTURE;
    ChangeFenetre();
}

/**
 * Op�re un basculement sur la page permettant une exploration de l'ordinateur
 */
void FuXFenetre::AfficheGestPeriph(wxCommandEvent &WXUNUSED(event))
{
    m_nouvelleFenetre = GESTIONPERIPH;
    ChangeFenetre();
}

/**
 * Provoque la fermeture du programme
 */
void FuXFenetre::Quitter(wxCommandEvent &WXUNUSED(event))
{    Close(true);}

/**
 * Barre de menu : relance la lecture
 */
void FuXFenetre::Lecture(wxCommandEvent &WXUNUSED(event))
{
    FichierLog::Get()->Ajouter("FuXFenetre::Lecture - Barre de menu");
    if (m_chanson->GetLecture())
        m_chanson->SetPause(true);
    else if (m_chanson->GetPause())
        m_chanson->SetPause(false);
    else
        m_chanson->ChangementChanson(IDENTIQUE);

    if (m_chanson->GetLecture())
    {
        m_boutonImageLP->SetBitmapLabel(m_imageBouton[PAUS]);
        menuControle->FindItem(ID_APP_BAR_LECTURE)->SetItemLabel(_("Pause\tCtrl-P"));
    }
    else
    {
        m_boutonImageLP->SetBitmapLabel(m_imageBouton[LECT]);
        menuControle->FindItem(ID_APP_BAR_LECTURE)->SetItemLabel(_("Lecture\tCtrl-P"));
    }
}

/**
 * Relance la lecture si un titre est charg�, ouvre une fen�tre de s�lection sinon
 */
void FuXFenetre::BoutonLecture(wxCommandEvent &event)
{
    FichierLog::Get()->Ajouter("FuXFenetre::BoutonLecture");
    if (m_chanson->GetLecture())//En lecture
    {
        m_chanson->SetPause(true);
        m_boutonImageLP->SetBitmapLabel(m_imageBouton[LECT]);
        menuControle->FindItem(ID_APP_BAR_LECTURE)->SetItemLabel(_("Pause\tCtrl-P"));//"));//
    }
    else if (m_chanson->GetFichier()->GetNombreFichier() == 0)//Pas de fichier charg�
        OuvrirChanson(event);
    else if (m_chanson->GetPause())//En pause
    {
        m_chanson->SetPause(false);
        m_boutonImageLP->SetBitmapLabel(m_imageBouton[PAUS]);
        menuControle->FindItem(ID_APP_BAR_LECTURE)->SetItemLabel(_("Lecture\tCtrl-P"));//"));//
    }
    else//Musique stopp�e
    {
        m_chanson->ChangementChanson(IDENTIQUE);
        if (m_chanson->GetLecture())
        {
            m_boutonImageLP->SetBitmapLabel(m_imageBouton[PAUS]);
            menuControle->FindItem(ID_APP_BAR_LECTURE)->SetItemLabel(_("Pause\tCtrl-P"));//"));//
        }
        else
        {
            m_boutonImageLP->SetBitmapLabel(m_imageBouton[LECT]);
            menuControle->FindItem(ID_APP_BAR_LECTURE)->SetItemLabel(_("Lecture\tCtrl-P"));//"));//
        }
    }
    ChangeFenetre();
}

/**
 * Modifie l'image du bouton lecture/pause en fonction de l'�tat du syst�me
 */
void FuXFenetre::BoutonChangeImage(wxCommandEvent &event)
{
    FichierLog::Get()->Ajouter("FuXFenetre::BoutonChangeImage - bascule image Lecture/Pause");
    if (event.GetInt() == 1)
    {
        m_boutonImageLP->SetBitmapLabel(m_imageBouton[LECT]);
        menuControle->FindItem(ID_APP_BAR_LECTURE)->SetItemLabel(_("Lecture\tCtrl-P"));
    }
    else
    {
        m_boutonImageLP->SetBitmapLabel(m_imageBouton[PAUS]);
        menuControle->FindItem(ID_APP_BAR_LECTURE)->SetItemLabel(_("Pause\tCtrl-P"));
    }
    ChangeFenetre();
}

/**
 * Arr�te la chanson
 */
void FuXFenetre::Stop(wxCommandEvent &WXUNUSED(event))
{
    FichierLog::Get()->Ajouter("FuXFenetre::Stop");
    m_chanson->SetStop();
    menuControle->FindItem(ID_APP_BAR_LECTURE)->SetItemLabel(_("Lecture\tCtrl-P"));
    m_boutonImageLP->SetBitmapLabel(m_imageBouton[LECT]);
}

/**
 * Passe au titre suivant
 */
void FuXFenetre::Suivant(wxCommandEvent &WXUNUSED(event))
{
    FichierLog::Get()->Ajouter("FuXFenetre::suivant");
    m_chanson->ChangementChanson(SUIVANT);
    ChangeFenetre();
}

/**
 * Passe au titre pr�c�dent
 */
void FuXFenetre::Precedent(wxCommandEvent &WXUNUSED(event))
{
    FichierLog::Get()->Ajouter("FuXFenetre::Precedent");
    m_chanson->ChangementChanson(PRECEDENT);
    ChangeFenetre();
}

/**
 * Active/D�sactive la r�p�tition
 */
void FuXFenetre::Repete(wxCommandEvent &WXUNUSED(event))
{    m_chanson->SetRepete(!m_chanson->GetRepete());}

/**
 * Active/D�sactive la lecture al�atoire
 */
void FuXFenetre::Aleatoire(wxCommandEvent &WXUNUSED(event))
{    m_chanson->SetAleatoire(!m_chanson->GetAleatoire());}

/**
 * Ouvre une fen�tre pour choisir le ou les titres de musique � lire. Ajoute le(s) titre(s) � liste si celle-ci n'est pas vide
 */
void FuXFenetre::OuvrirChanson(wxCommandEvent &WXUNUSED(event))
{
    FichierLog::Get()->Ajouter("FuXFenetre::OuvrirChanson");
    int ouvert;
    wxFileDialog navig(this, _("Choisissez une chanson"), Parametre::Get()->getRepertoireDefaut(), "", Parametre::Get()->getFiltre(), wxFD_OPEN | wxFD_MULTIPLE | wxFD_FILE_MUST_EXIST);//";*.wav");

    ouvert = navig.ShowModal();

    if (ouvert == wxID_OK)
    {
        wxArrayString musNav;
        navig.GetPaths(musNav);
        /*for (int i = 0; i<musNav.GetCount(); i++)
            musNav.Item(i).SetChar(0, musNav.Item(i).Upper()[0]);*/

        if (m_chanson->GetFichier()->GetNombreFichier() == 0)
        {
            m_chanson->Lecture(musNav.Item(0));
            if (musNav.GetCount() == 1)
                m_chanson->Listage();
            else if (musNav.GetCount() >= 2)
                m_chanson->Listage(&musNav);
        }
        else
        {
            if (musNav.GetCount() == 1)
                m_chanson->Listage(musNav.Item(0));
            else if (musNav.GetCount() >= 2)
                m_chanson->Listage(&musNav);
        }
        musNav.Clear();
        m_playList->GetListeLecture()->MAJ();
        GestPeriph::Get()->MAJPlaylist();
    }
}

/**
 * Ouvre une fen�tre afin de choisir une liste de lecture enregistr�e
 */
void FuXFenetre::OuvrirM3U(wxCommandEvent &WXUNUSED(event))
{
    FichierLog::Get()->Ajouter("FuXFenetre::OuvrirM3U");
    int ouvert;
    wxFileDialog navig(this, _("Choisissez une playlist (fichier .m3u)"), Parametre::Get()->getRepertoireParametre("Play_list_M3U"), "", "Playlist (*.m3u)|*.m3u", wxFD_OPEN | wxFD_FILE_MUST_EXIST);

    ouvert = navig.ShowModal();

    if (ouvert == wxID_OK)
    {
        wxString chemin;
        chemin = navig.GetPath();

        wxTextFile test(chemin); test.Open();
        if (test.IsOpened())
        {
            if (test.GetLineCount() > 1)
            {
                if (m_chanson->GetFichier()->GetNombreFichier() == 0)
                {
                    //int ligne = m_chanson->GetFichier()->GetNombreFichier();
                    m_chanson->CopieFichier(chemin);
                    m_chanson->ChangementChanson(0, "");
                    //m_chanson->Lecture(m_chanson->GetFichier()->GetNomPosition(0));
                }
                else
                    m_chanson->CopieFichier(chemin);
                m_playList->GetListeLecture()->MAJ();
                GestPeriph::Get()->MAJPlaylist();
            }
            else wxLogMessage(_("Impossible d'ouvrir le fichier, celui-ci est vierge !"));
            test.Close();
        }
    }
}

/**
 * Supprime le titre en cours de diffusion de la liste de lecture
 */
void FuXFenetre::SupprimerListe(wxCommandEvent &WXUNUSED(event))
{
    FichierLog::Get()->Ajouter("FuXFenetre::SupprimerListe");
    m_playList->GetListeLecture()->supprimerNomLigne(m_chanson->SupprimerNom());
    m_periph->MAJPlaylist();
    ChangeFenetre();
}

/**
 * �change la page actuelle contre une autre page (effectue l'op�ration)
 */
void FuXFenetre::ChangeFenetre()/////////////////
{
    if (m_FenetreActuel != m_nouvelleFenetre && m_panelsAssocies[m_nouvelleFenetre])
    {
        //if ()
            switch(m_FenetreActuel)
            {
                case PRINCIPAL:
                    if (sizerDroitPrincipal)
                        sizerDroit->Hide(sizerDroitPrincipal);
                    break;
                case PREFERENCE:
                    if (sizerDroitPreference)
                        sizerDroit->Hide(sizerDroitPreference);
                    break;
                case ENCODAGE:
                    if (sizerDroitExtracteur)
                        sizerDroit->Hide(sizerDroitExtracteur);
                    break;
                case LISTELECTURE:
                    if (sizerDroitPlayist)
                        sizerDroit->Hide(sizerDroitPlayist);
                    break;
                case GESTIONPERIPH:
                    if (sizerDroitIPod)
                        sizerDroit->Hide(sizerDroitIPod);
                    break;
            }
        switch(m_nouvelleFenetre)
        {
            case PRINCIPAL:
                m_FenetreActuel = PRINCIPAL;
                sizerDroit->Show(sizerDroitPrincipal);
                break;
            case PREFERENCE:
                m_FenetreActuel = PREFERENCE;
                sizerDroit->Show(sizerDroitPreference);
                break;
            case ENCODAGE:
                m_FenetreActuel = ENCODAGE;
                sizerDroit->Show(sizerDroitExtracteur);
                break;
            case LISTELECTURE:
                m_FenetreActuel = LISTELECTURE;
                sizerDroit->Show(sizerDroitPlayist);
                break;
            case GESTIONPERIPH:
                m_FenetreActuel = GESTIONPERIPH;
                sizerDroit->Show(sizerDroitIPod);
                break;
        }
    }
    switch(m_nouvelleFenetre)
    {
        case PRINCIPAL:
            m_musiqueGraph->SetFocus();
            break;
        case PREFERENCE:
            NotebookPreference->SetFocus();
            break;
        case ENCODAGE:
            break;
        case LISTELECTURE:
            m_playList->GetListeLecture()->SetFocus();
            break;
        case GESTIONPERIPH:
            m_periph->SetFocus();
            break;
    }
    sizerDroit->Layout();
}

/**
 * Modifie le volume sonore
 */
void FuXFenetre::ModifSon(wxScrollEvent &WXUNUSED(event))
{
    m_chanson->SetVolume(SliderSon::Get()->GetValue());
    m_pageSon.SetValeurMusique(SliderSon::Get()->GetValue());
    ChangeFenetre();
}

/**
 * Provoque les changements n�cessaires afin de s'adapter � la nouvelle situation : changement de titre ou suppression de tous les titres
 */
void FuXFenetre::ChangementChanson(wxCommandEvent &event)
{
    FichierLog::Get()->Ajouter("FuXFenetre::ChangementChanson");
    if (event.GetInt())
    {
        m_playList->GetListeLecture()->ChangementChanson(m_chanson->GetNomPos());
        m_boutonImageLP->SetBitmapLabel(m_imageBouton[PAUS]);
        menuControle->FindItem(ID_APP_BAR_LECTURE)->SetItemLabel(_("Pause\tCtrl-P"));//"));//
    }
    else
    {
        m_boutonImageLP->SetBitmapLabel(m_imageBouton[LECT]);
        menuControle->FindItem(ID_APP_BAR_LECTURE)->SetItemLabel(_("Lecture\tCtrl-P"));//"));//
    }
}

/**
 * Provoque une mise � jour de la liste de lecture affich�e � l'utilisateur
 */
void FuXFenetre::MAJplaylist(wxCommandEvent &WXUNUSED(event))
{
    m_playList->GetListeLecture()->MAJ();
    GestPeriph::Get()->MAJPlaylist();
}

/**
 * Affiche une fen�tre permettant l'enregistrement de la liste de lecture
 */
void FuXFenetre::SauvegardeListeLecture(wxCommandEvent &event)
{    m_playList->EnregistrerM3U(event);}

/**
 * Affiche le menu About de l'application
 */
void FuXFenetre::MenuAbout(wxCommandEvent &WXUNUSED(event))
{
    wxString message(_T("Nom : Fu(X) 2.0\tVersion : a5\tDate : " + wxString(__DATE__) + "\n\nAuteur : David Lecoconnier (etrange02@aol.com)\n\nInterface r�alis�e avec wxWidgets 2.8.10\n\n\n" +
                        "Copyright � 2009-2012 David Lecoconnier, tous droits r�serv�s\n\nFMOD Sound System, copyright � Firelight Technologies Pty, Ltd., 1994-2007\n"));
    wxMessageBox(message, _("A propos"), wxOK | wxICON_INFORMATION, this);
}

/**
 * Affiche le site de l'application � travers le navigateur internet
 */
void FuXFenetre::MenuSiteWeb(wxCommandEvent &WXUNUSED(event))
{    wxLaunchDefaultBrowser(_T("http://fuxplay.com/"));}

/**
 * Affiche la page d'aide � travers le navigateur internet
 */
void FuXFenetre::MenuAide(wxCommandEvent &WXUNUSED(event))
{    wxLaunchDefaultBrowser(_T("http://fuxplay.com/aide.php"));}

/**
 * Lit les pr�f�rences se trouvant dans le fichier de configuration si celui-ci existe
 * @param lecture Si vrai, l'application cherche � lancer le fichier enregistr� comme devant �tre lanc� � l'ouverture de l'application
 */
void FuXFenetre::LecturePreference(bool lecture)
{
    FichierLog::Get()->Ajouter("FuXFenetre::LecturePreference");
    wxString cheminFichier = Parametre::Get()->getRepertoireParametre("Fu(X).conf") , nomFichierCouleur, nomFichierSon;
    wxTextFile fichierPref(cheminFichier);

    if (!(fichierPref.Exists() && fichierPref.Open()))
        return;

    if (fichierPref.GetLine(0).IsSameAs("#EXTCONF_1"))
    {
        ///////Couleur
        if (!fichierPref.GetLine(1).IsSameAs("Couleur= NON"))
            m_pageCouleur.Couleur_OuvrirFichier(fichierPref.GetLine(1).AfterFirst(' '), false);

        ///////Son
        if (!fichierPref.GetLine(2).IsSameAs("Son= NON"))
        {
            long volume;
            nomFichierSon = Parametre::Get()->getRepertoireParametre("Preference", "Son", fichierPref.GetLine(2).AfterFirst(' '));
            wxTextFile fichierS(nomFichierSon);
            fichierS.Open();
            if (fichierS.GetLine(0).IsSameAs("#EXTSAUVE_S1"))
            {
                fichierS.GetLine(2).ToLong(&volume);
                m_chanson->SetVolume(volume);
                SliderSon::Get()->SetValue(volume);
                m_pageSon.SetValeurMusique(volume);
                fichierS.Close();
            }
        }
        ///////Sous-dossier
        if (fichierPref.GetLine(5) != "SousDossier= NON")
            Parametre::Get()->setSousDossier(true);
        /////////Reprise
        if (lecture && !(fichierPref.GetLine(3).IsSameAs("Reprise= NON")))
        {
            if (fichierPref.GetLine(3).IsSameAs("Reprise= M3U"))
            {
                wxString cheminM3U = Parametre::Get()->getRepertoireParametre("Play_list_M3U", fichierPref.GetLine(4).AfterFirst(' '));

                wxTextFile test(cheminM3U);
                if (test.Open())
                {
                    if (test.GetLineCount() > 1)
                    {
                        m_chanson->CopieFichier(cheminM3U);
                        m_chanson->Lecture(m_chanson->GetFichier()->GetNomPosition(0));
                        m_MAJliste = true;
                    }
                    else wxLogMessage(_("Impossible d'ouvrir le fichier, celui-ci est vierge !"));
                    test.Close();
                }
            }
            else if (fichierPref.GetLine(3).IsSameAs("Reprise= MP3"))
            {
                m_chanson->Lecture(fichierPref.GetLine(4).AfterFirst(' '));
                m_chanson->Listage();
                m_MAJliste = true;
            }
        }
    }
    else
        wxLogMessage(_("Vous devez mettre les param�tres par d�faut de Fu(X) � jour.\nMerci de votre compr�hension"));

    fichierPref.Close();
}

/**
 * Bascule sur la page des Pr�f�rences, onglet Couleur, choix sur nouveau
 */
void FuXFenetre::AffichCouleurNouv(wxCommandEvent &WXUNUSED(event))
{
    m_nouvelleFenetre = PREFERENCE;
    ChangeFenetre();
    NotebookPreference->ChangeSelection(0);
    m_pageCouleur.GetRadioBox()->SetSelection(0);
    m_pageCouleur.Couleur_Modif_Nouveau(0);
}


/**
 * Bascule sur la page des Pr�f�rences, onglet Couleur, choix sur modifier
 */
void FuXFenetre::AffichCouleurMod(wxCommandEvent &WXUNUSED(event))
{
    m_nouvelleFenetre = PREFERENCE;
    ChangeFenetre();
    NotebookPreference->ChangeSelection(0);
    m_pageCouleur.GetRadioBox()->SetSelection(1);
    m_pageCouleur.Couleur_Modif_Nouveau(1);
}


/**
 * Bascule sur la page des Pr�f�rences, onglet Son, choix sur nouveau
 */
void FuXFenetre::AffichSonNouv(wxCommandEvent &WXUNUSED(event))
{
    m_nouvelleFenetre = PREFERENCE;
    ChangeFenetre();
    NotebookPreference->ChangeSelection(1);
    m_pageSon.GetRadioBox()->SetSelection(0);
    m_pageSon.Son_Modif_Nouveau(0);
}


/**
 * Bascule sur la page des Pr�f�rences, onglet Son, choix sur modifier
 */
void FuXFenetre::AffichSonMod(wxCommandEvent &WXUNUSED(event))
{
    m_nouvelleFenetre = PREFERENCE;
    ChangeFenetre();
    NotebookPreference->ChangeSelection(1);
    m_pageSon.GetRadioBox()->SetSelection(1);
    m_pageSon.Son_Modif_Nouveau(1);
}

/**
 * �v�nement provenant du serveur de l'application : un titre ajout�
 */
void FuXFenetre::EvtServeurAjout(wxCommandEvent &event)
{
    FichierLog::Get()->Ajouter("FuXFenetre::EvtServeurAjout");
    wxArrayString *a = m_serveur->GetConnexionTableau(event.GetInt());

    bool lire = m_chanson->IsContainingMus();
    m_chanson->Listage(a, false);
    if (lire)
        m_chanson->ChangementChanson(-1, a->Item(0));
    m_serveur->Deconnecter(event.GetInt());
    m_playList->GetListeLecture()->MAJ();
}

/**
 *
 */
void FuXFenetre::OnTitreChange(wxCommandEvent &WXUNUSED(event))
{    FichierLog::Get()->Ajouter("FuXFenetre::OnTitreChange"); m_musiqueGraph->TitreChange();}

/**
 * �v�nements clavier - Utilisation des raccourcis g�n�raux (titre suivant, volume, ...)
 * @param event l'�v�nement � analyser
 */
void FuXFenetre::OnKeyDownRaccourci(wxKeyEvent &event)
{
    FichierLog::Get()->Ajouter("FuXFenetre::OnKeyDownRaccourci");
    if (event.ControlDown())
    {
        switch (event.GetKeyCode())
        {
            case '+':
            case WXK_ADD:
            case WXK_NUMPAD_ADD:
                SliderSon::Get()->SonUp();
                break;
            case '-':
            case '6':
            case WXK_SUBTRACT:
            case WXK_NUMPAD_SUBTRACT:
                SliderSon::Get()->SonDown();
                break;
            default :
                event.Skip();
        }
    }
    else
        event.Skip();
}

/**
 * �v�nement - Permet la s�paration des pages dans diff�rentes fen�tres
 * @param event
 */
void FuXFenetre::SeparationPanel(wxCommandEvent &event)
{
    if (!m_panelsAssocies[event.GetInt()])
        return;
    switch(event.GetInt())
    {
        case PRINCIPAL:
            sizerDroit->Detach(sizerDroitPrincipal);
            m_fenetresDetachables->Add(this, (wxWindow*) m_musiqueGraph, sizerDroitPrincipal, PRINCIPAL, event.GetId(), _("Graphe - Fu(X) 2.0"));
            sizerDroitPrincipal = NULL;
            FichierLog::Get()->Ajouter("FuXFenetre::SeparationPanel - PRINCIPAL");
            break;
        case LISTELECTURE:
            sizerDroit->Detach(sizerDroitPlayist);
            m_fenetresDetachables->Add(this, (wxWindow*) m_playList, sizerDroitPlayist, LISTELECTURE, event.GetId(), _("Liste de lecture - Fu(X) 2.0"));
            sizerDroitPlayist = NULL;
            FichierLog::Get()->Ajouter("FuXFenetre::SeparationPanel - LISTELECTURE");
            break;
        case GESTIONPERIPH:
            sizerDroit->Detach(sizerDroitIPod);
            m_fenetresDetachables->Add(this, (wxWindow*) m_periph, sizerDroitIPod, GESTIONPERIPH, event.GetId(), _("Exploration - Fu(X) 2.0"));
            sizerDroitIPod = NULL;
            FichierLog::Get()->Ajouter("FuXFenetre::SeparationPanel - GESTIONPERIPH");
            break;
    }
    m_panelsAssocies[event.GetInt()] = false;

    if (!m_panelsAssocies[m_FenetreActuel])
    {
        if (m_panelsAssocies[PRINCIPAL])
            m_nouvelleFenetre = PRINCIPAL;
        else if (m_panelsAssocies[LISTELECTURE])
            m_nouvelleFenetre = LISTELECTURE;
        else if (m_panelsAssocies[GESTIONPERIPH])
            m_nouvelleFenetre = GESTIONPERIPH;
        else if (m_panelsAssocies[PREFERENCE])
            m_nouvelleFenetre = PREFERENCE;
    }

    ChangeFenetre();
    m_nouvelleFenetre = event.GetInt();
    ChangeFenetre();
}

/**
 * �v�nement - Permet la r�int�gration des pages dans la fen�tre principale
 * @param event
 */
void FuXFenetre::ReunionPanel(wxCommandEvent &event)
{
    FenetreDetachable *f = m_fenetresDetachables->GetFenetreByType(event.GetInt());
    if (f == NULL)
        return;

    wxBoxSizer *s = NULL;
    switch(event.GetInt())
    {
        case PRINCIPAL:
            sizerDroitPrincipal = (wxBoxSizer*) f->RetourNormale();
            s = sizerDroitPrincipal;
            FichierLog::Get()->Ajouter("FuXFenetre::ReunionPanel - PRINCIPAL");
            break;
        case LISTELECTURE:
            sizerDroitPlayist = (wxBoxSizer*)f->RetourNormale();
            s = sizerDroitPlayist;
            FichierLog::Get()->Ajouter("FuXFenetre::ReunionPanel - LISTELECTURE");
            break;
        case GESTIONPERIPH:
            sizerDroitIPod = (wxBoxSizer*)f->RetourNormale();
            s = sizerDroitIPod;
            FichierLog::Get()->Ajouter("FuXFenetre::ReunionPanel - GESTIONPERIPH");
            break;
    }
    if (s)
    {
        m_panelsAssocies[event.GetInt()] = true;
        sizerDroit->Add(s, 1, wxALL | wxEXPAND, 0);
        sizerDroit->Show(s);
        sizerDroit->Layout();
        if (m_FenetreActuel != event.GetInt())
            sizerDroit->Hide(s);
        m_nouvelleFenetre = m_FenetreActuel;
    }
    sizerDroit->Layout();

    if (f)
    {
        f->~FenetreDetachable();
        m_fenetresDetachables->Remove(f);
    }
}



